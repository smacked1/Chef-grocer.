
1. Info.plist keys for iOS were added to app.json under expo.ios.infoPlist. Confirm or adjust the wording before building native iOS binary.

2. Privacy policy created at: /client/public/privacy.html
   - Host this page at your domain and use its absolute URL in App Store Connect as Privacy Policy.

3. Service Worker updated to avoid caching API responses (client/public/sw.js).
   - This prevents sensitive user/AI responses from being stored offline.

4. Server improvements:
   - helmet() and compression() enabled in server/index.ts.
   - setupAuth is conditionally enabled based on environment variable ENABLE_AUTH (set to 'true' in production).
   - strictRateLimit is applied to /api/ai endpoints.

5. A small in-app AI disclosure component added at client/src/components/AIDisclosure.tsx.
   - Import and show this on pages that display AI-generated content (e.g., recipe suggestions, meal-plan pages).

6. Next steps before submitting to App Store:
   - Host privacy policy URL and update APP-STORE-SUBMISSION.md with the real URL.
   - Set ENABLE_AUTH=true in production and configure your auth provider (see server/replitAuth.ts).
   - Ensure no API keys are present in client bundles and that server env vars (API keys) are set on your hosted server.
   - Test on device via TestFlight: voice permissions, AI flows, offline fallback behavior.

