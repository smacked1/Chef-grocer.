import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb, timestamp, boolean, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for authentication and subscription management
export const users = pgTable("users", {
  id: varchar("id").primaryKey(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  subscriptionPlan: varchar("subscription_plan").default("free"),
  subscriptionStatus: varchar("subscription_status").default("inactive"),
  trialEndsAt: timestamp("trial_ends_at"),
  trialUsed: boolean("trial_used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const recipes = pgTable("recipes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  ingredients: jsonb("ingredients").$type<string[]>().notNull(),
  instructions: jsonb("instructions").$type<string[]>().notNull(),
  cookTime: integer("cook_time").notNull(),
  servings: integer("servings").notNull(),
  difficulty: text("difficulty").notNull(),
  rating: integer("rating").default(0),
  imageUrl: text("image_url"),
  tags: jsonb("tags").$type<string[]>().default([]),
  calories: integer("calories"),
  caloriesPerServing: integer("calories_per_serving"),
  nutritionInfo: jsonb("nutrition_info").$type<{
    protein?: number;
    carbs?: number;
    fat?: number;
    fiber?: number;
    sugar?: number;
  }>(),
  estimatedCost: text("estimated_cost"),
  costPerServing: text("cost_per_serving"),
  createdAt: timestamp("created_at").defaultNow()
});

export const mealPlans = pgTable("meal_plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: text("date").notNull(),
  mealType: text("meal_type").notNull(), // breakfast, lunch, dinner
  recipeId: varchar("recipe_id").references(() => recipes.id),
  recipeName: text("recipe_name").notNull(),
  cookTime: integer("cook_time").notNull(),
  status: text("status").default("planned"), // planned, cooking, completed
  currentStep: integer("current_step").default(0),
  createdAt: timestamp("created_at").defaultNow()
});

export const groceryItems = pgTable("grocery_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  quantity: text("quantity").notNull(),
  category: text("category").default("other"),
  completed: boolean("completed").default(false),
  addedBy: text("added_by").default("user"), // user, ai
  estimatedPrice: text("estimated_price"),
  actualPrice: text("actual_price"),
  bestStore: text("best_store"),
  storeLink: text("store_link"),
  couponCode: text("coupon_code"),
  onSale: boolean("on_sale").default(false),
  saleSavings: text("sale_savings"),
  imageUrl: text("image_url"),
  notes: text("notes"),
  priority: integer("priority").default(1), // 1-5
  createdAt: timestamp("created_at").defaultNow()
});

export const pantryItems = pgTable("pantry_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  quantity: text("quantity").notNull(),
  unit: text("unit").notNull(),
  expiryDate: text("expiry_date"),
  status: text("status").default("normal"), // normal, low, expired
  purchasePrice: text("purchase_price"),
  purchaseDate: text("purchase_date"),
  purchaseStore: text("purchase_store"),
  calories: integer("calories"),
  createdAt: timestamp("created_at").defaultNow()
});

export const stores = pgTable("stores", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // grocery, supermarket, online, farmers_market
  address: text("address"),
  website: text("website"),
  priceRating: integer("price_rating").default(3), // 1-5, 1 being cheapest
  qualityRating: integer("quality_rating").default(3),
  distance: text("distance"),
  deliveryAvailable: boolean("delivery_available").default(false),
  curbsideAvailable: boolean("curbside_available").default(false),
  specialOffers: jsonb("special_offers").$type<string[]>().default([]),
  createdAt: timestamp("created_at").defaultNow()
});

export const shoppingTips = pgTable("shopping_tips", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // budgeting, coupons, seasonal, bulk_buying
  tipType: text("tip_type").notNull(), // savings, quality, timing
  estimatedSavings: text("estimated_savings"),
  difficulty: text("difficulty").default("easy"), // easy, medium, advanced
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow()
});

export const foodDatabase = pgTable("food_database", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  category: text("category").notNull(), // fruits, vegetables, proteins, grains, dairy, etc.
  subCategory: text("sub_category"), // citrus, leafy_greens, red_meat, etc.
  brand: text("brand"),
  barcode: text("barcode"),
  servingSize: text("serving_size").notNull(),
  calories: integer("calories").notNull(),
  nutritionInfo: jsonb("nutrition_info").$type<{
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    sugar: number;
    sodium: number;
    cholesterol?: number;
    potassium?: number;
    vitaminA?: number;
    vitaminC?: number;
    calcium?: number;
    iron?: number;
  }>().notNull(),
  allergens: jsonb("allergens").$type<string[]>().default([]),
  dietaryTags: jsonb("dietary_tags").$type<string[]>().default([]), // vegan, vegetarian, gluten_free, keto, etc.
  averagePrice: text("average_price"),
  seasonality: text("seasonality"), // spring, summer, fall, winter, year_round
  storageInstructions: text("storage_instructions"),
  shelfLife: text("shelf_life"),
  preparationTips: jsonb("preparation_tips").$type<string[]>().default([]),
  commonUses: jsonb("common_uses").$type<string[]>().default([]),
  isOrganic: boolean("is_organic").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const deliveryServices = pgTable("delivery_services", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(), // DoorDash, Grubhub, Uber Eats, etc.
  type: text("type").notNull(), // food_delivery, grocery_delivery, restaurant_delivery
  websiteUrl: text("website_url").notNull(),
  apiEndpoint: text("api_endpoint"),
  supportedAreas: jsonb("supported_areas").$type<string[]>().default([]),
  averageDeliveryTime: text("average_delivery_time"),
  deliveryFee: text("delivery_fee"),
  minimumOrder: text("minimum_order"),
  features: jsonb("features").$type<string[]>().default([]), // real_time_tracking, scheduled_delivery, etc.
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow()
});

export const restaurantMenuItems = pgTable("restaurant_menu_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  restaurantName: text("restaurant_name").notNull(),
  itemName: text("item_name").notNull(),
  description: text("description"),
  category: text("category").notNull(), // appetizers, mains, desserts, beverages
  price: text("price").notNull(),
  calories: integer("calories"),
  nutritionInfo: jsonb("nutrition_info").$type<{
    protein?: number;
    carbs?: number;
    fat?: number;
    fiber?: number;
    sugar?: number;
    sodium?: number;
  }>(),
  allergens: jsonb("allergens").$type<string[]>().default([]),
  dietaryTags: jsonb("dietary_tags").$type<string[]>().default([]),
  ingredients: jsonb("ingredients").$type<string[]>().default([]),
  imageUrl: text("image_url"),
  isAvailable: boolean("is_available").default(true),
  deliveryServiceId: varchar("delivery_service_id").references(() => deliveryServices.id),
  doordashUrl: text("doordash_url"),
  grubhubUrl: text("grubhub_url"),
  ubereatsUrl: text("ubereats_url"),
  createdAt: timestamp("created_at").defaultNow()
});



export const subscriptionPlans = pgTable("subscription_plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  stripePriceId: text("stripe_price_id").notNull(),
  price: integer("price").notNull(), // in cents
  interval: text("interval").notNull(), // month, year, lifetime
  features: jsonb("features").$type<string[]>().notNull(),
  isActive: boolean("is_active").default(true),
  trialDays: integer("trial_days").default(7), // 7-day free trial
  maxUsers: integer("max_users"), // limit for lifetime plans (e.g., 100)
  currentUsers: integer("current_users").default(0), // count of users who purchased
  createdAt: timestamp("created_at").defaultNow()
});

export const coupons = pgTable("coupons", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  discountType: text("discount_type").notNull(), // percentage, fixed_amount
  discountValue: integer("discount_value").notNull(), // percentage or cents
  minAmount: integer("min_amount").default(0), // minimum order amount in cents
  maxUses: integer("max_uses"), // null = unlimited
  usedCount: integer("used_count").default(0),
  validFrom: timestamp("valid_from").defaultNow(),
  validUntil: timestamp("valid_until"),
  isActive: boolean("is_active").default(true),
  applicablePlans: jsonb("applicable_plans").$type<string[]>().default([]), // empty = all plans
  createdAt: timestamp("created_at").defaultNow()
});

export const userCoupons = pgTable("user_coupons", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  couponId: varchar("coupon_id").references(() => coupons.id),
  usedAt: timestamp("used_at").defaultNow(),
  discountAmount: integer("discount_amount").notNull(), // actual discount applied in cents
  createdAt: timestamp("created_at").defaultNow()
});

export const paymentTransactions = pgTable("payment_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  stripePaymentIntentId: text("stripe_payment_intent_id").notNull(),
  amount: integer("amount").notNull(), // in cents
  currency: text("currency").default("usd"),
  status: text("status").notNull(), // pending, succeeded, failed, canceled
  paymentType: text("payment_type").notNull(), // subscription, one_time, meal_plan
  description: text("description"),
  metadata: jsonb("metadata").$type<Record<string, any>>().default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const premiumMealPlans = pgTable("premium_meal_plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(), // in cents
  duration: integer("duration").notNull(), // days
  meals: jsonb("meals").$type<{
    day: number;
    breakfast?: string;
    lunch?: string;
    dinner?: string;
    snacks?: string[];
  }[]>().notNull(),
  nutritionGoals: jsonb("nutrition_goals").$type<{
    calories?: number;
    protein?: number;
    carbs?: number;
    fat?: number;
  }>(),
  dietaryTags: jsonb("dietary_tags").$type<string[]>().default([]),
  imageUrl: text("image_url"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
  createdAt: true
});

export const insertMealPlanSchema = createInsertSchema(mealPlans).omit({
  id: true,
  createdAt: true
});

export const insertGroceryItemSchema = createInsertSchema(groceryItems).omit({
  id: true,
  createdAt: true
});

export const insertPantryItemSchema = createInsertSchema(pantryItems).omit({
  id: true,
  createdAt: true
});

export const insertStoreSchema = createInsertSchema(stores).omit({
  id: true,
  createdAt: true
});

export const insertShoppingTipSchema = createInsertSchema(shoppingTips).omit({
  id: true,
  createdAt: true
});

export const insertFoodDatabaseSchema = createInsertSchema(foodDatabase).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertDeliveryServiceSchema = createInsertSchema(deliveryServices).omit({
  id: true,
  createdAt: true
});

export const insertRestaurantMenuItemSchema = createInsertSchema(restaurantMenuItems).omit({
  id: true,
  createdAt: true
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans).omit({
  id: true,
  createdAt: true
});

export const insertPaymentTransactionSchema = createInsertSchema(paymentTransactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertPremiumMealPlanSchema = createInsertSchema(premiumMealPlans).omit({
  id: true,
  createdAt: true
});

export const insertCouponSchema = createInsertSchema(coupons).omit({
  id: true,
  createdAt: true,
  usedCount: true
});

export const insertUserCouponSchema = createInsertSchema(userCoupons).omit({
  id: true,
  createdAt: true
});

export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type MealPlan = typeof mealPlans.$inferSelect;
export type InsertMealPlan = z.infer<typeof insertMealPlanSchema>;
export type GroceryItem = typeof groceryItems.$inferSelect;
export type InsertGroceryItem = z.infer<typeof insertGroceryItemSchema>;
export type PantryItem = typeof pantryItems.$inferSelect;
export type InsertPantryItem = z.infer<typeof insertPantryItemSchema>;
export type Store = typeof stores.$inferSelect;
export type InsertStore = z.infer<typeof insertStoreSchema>;
export type ShoppingTip = typeof shoppingTips.$inferSelect;
export type InsertShoppingTip = z.infer<typeof insertShoppingTipSchema>;
export type FoodDatabaseItem = typeof foodDatabase.$inferSelect;
export type InsertFoodDatabaseItem = z.infer<typeof insertFoodDatabaseSchema>;
export type DeliveryService = typeof deliveryServices.$inferSelect;
export type InsertDeliveryService = z.infer<typeof insertDeliveryServiceSchema>;
export type RestaurantMenuItem = typeof restaurantMenuItems.$inferSelect;
export type InsertRestaurantMenuItem = z.infer<typeof insertRestaurantMenuItemSchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpsertUser = typeof users.$inferInsert;
export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = z.infer<typeof insertSubscriptionPlanSchema>;
export type PaymentTransaction = typeof paymentTransactions.$inferSelect;
export type InsertPaymentTransaction = z.infer<typeof insertPaymentTransactionSchema>;
export type PremiumMealPlan = typeof premiumMealPlans.$inferSelect;
export type InsertPremiumMealPlan = z.infer<typeof insertPremiumMealPlanSchema>;
export type Coupon = typeof coupons.$inferSelect;
export type InsertCoupon = z.infer<typeof insertCouponSchema>;
export type UserCoupon = typeof userCoupons.$inferSelect;
export type InsertUserCoupon = z.infer<typeof insertUserCouponSchema>;
