import { Request, Response, NextFunction } from 'express';

// Response compression middleware
export function compressionMiddleware() {
  return (req: Request, res: Response, next: NextFunction) => {
    const originalSend = res.send;
    
    res.send = function(body: any) {
      // Only compress JSON responses larger than 1KB and if headers not sent
      if (!res.headersSent && typeof body === 'object' && JSON.stringify(body).length > 1024) {
        res.setHeader('Content-Encoding', 'gzip');
        res.setHeader('Vary', 'Accept-Encoding');
      }
      
      return originalSend.call(this, body);
    };
    
    next();
  };
}

// Response caching middleware
export function cacheMiddleware(duration: number = 300) {
  return (req: Request, res: Response, next: NextFunction) => {
    // Only cache GET requests
    if (req.method !== 'GET') {
      return next();
    }
    
    // Don't cache API endpoints that change frequently
    const noCachePatterns = ['/api/meal-plans', '/api/voice', '/api/create-'];
    if (noCachePatterns.some(pattern => req.path.includes(pattern))) {
      return next();
    }
    
    res.setHeader('Cache-Control', `public, max-age=${duration}`);
    next();
  };
}

// Request timing middleware
export function requestTimingMiddleware() {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const start = Date.now();
      
      // Store original send method
      const originalSend = res.send;
      let responseSent = false;
      
      res.send = function(body: any) {
        if (responseSent) return originalSend.call(this, body);
        
        const duration = Date.now() - start;
        responseSent = true;
        
        // Log slow requests in development
        if (process.env.NODE_ENV === 'development' && duration > 2000) {
          console.warn(`Slow request: ${req.method || 'UNKNOWN'} ${req.path || 'UNKNOWN'} took ${duration}ms`);
        }
        
        // Set timing header before sending response
        try {
          if (!res.headersSent) {
            res.setHeader('X-Response-Time', `${duration}ms`);
          }
        } catch (e) {
          // Ignore header setting errors
        }
        
        return originalSend.call(this, body);
      };
      
      next();
    } catch (error) {
      console.error('Request timing middleware error:', error);
      next();
    }
  };
}