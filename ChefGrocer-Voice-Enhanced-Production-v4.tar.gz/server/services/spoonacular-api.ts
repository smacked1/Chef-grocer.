// Spoonacular API integration service
// Provides access to 365,000+ recipes, ingredients, and nutrition data

export interface SpoonacularRecipe {
  id: number;
  title: string;
  image: string;
  imageType: string;
  servings: number;
  readyInMinutes: number;
  license: string;
  sourceName: string;
  sourceUrl: string;
  spoonacularSourceUrl: string;
  aggregateLikes: number;
  healthScore: number;
  spoonacularScore: number;
  pricePerServing: number;
  analyzedInstructions: AnalyzedInstruction[];
  cheap: boolean;
  creditsText: string;
  cuisines: string[];
  dairyFree: boolean;
  diets: string[];
  gaps: string;
  glutenFree: boolean;
  instructions: string;
  ketogenic: boolean;
  lowFodmap: boolean;
  occasions: string[];
  sustainable: boolean;
  vegan: boolean;
  vegetarian: boolean;
  veryHealthy: boolean;
  veryPopular: boolean;
  whole30: boolean;
  weightWatcherSmartPoints: number;
  dishTypes: string[];
  extendedIngredients: ExtendedIngredient[];
  summary: string;
  winePairing?: WinePairing;
  nutrition?: Nutrition;
}

export interface ExtendedIngredient {
  aisle: string;
  amount: number;
  consistency: string;
  id: number;
  image: string;
  measures: Measures;
  meta: string[];
  name: string;
  nameClean: string;
  original: string;
  originalName: string;
  unit: string;
}

export interface Measures {
  us: UnitMeasure;
  metric: UnitMeasure;
}

export interface UnitMeasure {
  amount: number;
  unitShort: string;
  unitLong: string;
}

export interface AnalyzedInstruction {
  name: string;
  steps: Step[];
}

export interface Step {
  number: number;
  step: string;
  ingredients: Ingredient[];
  equipment: Equipment[];
  length?: Length;
}

export interface Ingredient {
  id: number;
  name: string;
  localizedName: string;
  image: string;
}

export interface Equipment {
  id: number;
  name: string;
  localizedName: string;
  image: string;
  temperature?: Temperature;
}

export interface Temperature {
  number: number;
  unit: string;
}

export interface Length {
  number: number;
  unit: string;
}

export interface WinePairing {
  pairedWines: string[];
  pairingText: string;
  productMatches: ProductMatch[];
}

export interface ProductMatch {
  id: number;
  title: string;
  description: string;
  price: string;
  imageUrl: string;
  averageRating: number;
  ratingCount: number;
  score: number;
  link: string;
}

export interface Nutrition {
  nutrients: Nutrient[];
  properties: Property[];
  flavonoids: Flavonoid[];
  ingredients: NutritionIngredient[];
  caloricBreakdown: CaloricBreakdown;
  weightPerServing: WeightPerServing;
}

export interface Nutrient {
  name: string;
  amount: number;
  unit: string;
  percentOfDailyNeeds: number;
}

export interface Property {
  name: string;
  amount: number;
  unit: string;
}

export interface Flavonoid {
  name: string;
  amount: number;
  unit: string;
}

export interface NutritionIngredient {
  id: number;
  name: string;
  amount: number;
  unit: string;
  nutrients: Nutrient[];
}

export interface CaloricBreakdown {
  percentProtein: number;
  percentFat: number;
  percentCarbs: number;
}

export interface WeightPerServing {
  amount: number;
  unit: string;
}

export interface SpoonacularSearchResult {
  results: SpoonacularRecipe[];
  offset: number;
  number: number;
  totalResults: number;
}

export interface SpoonacularIngredientSearchResult {
  results: SpoonacularIngredient[];
  offset: number;
  number: number;
  totalResults: number;
}

export interface SpoonacularIngredient {
  id: number;
  name: string;
  image: string;
}

export interface SpoonacularMealPlan {
  meals: MealPlanItem[];
  nutrients: Nutrient[];
}

export interface MealPlanItem {
  id: number;
  imageType: string;
  title: string;
  readyInMinutes: number;
  servings: number;
  sourceUrl: string;
}

class SpoonacularService {
  private readonly baseUrl = 'https://api.spoonacular.com';
  private readonly apiKey: string;

  constructor() {
    this.apiKey = process.env.SPOONACULAR_API_KEY || '';
    if (!this.apiKey) {
      console.warn('Spoonacular API key not found. Set SPOONACULAR_API_KEY environment variable.');
    }
  }

  private async makeRequest<T>(endpoint: string, params: Record<string, any> = {}): Promise<T> {
    if (!this.apiKey) {
      throw new Error('Spoonacular API key is required');
    }

    const searchParams = new URLSearchParams({
      apiKey: this.apiKey,
      ...params
    });

    const url = `${this.baseUrl}${endpoint}?${searchParams}`;
    
    try {
      const response = await fetch(url);
      
      if (!response.ok) {
        if (response.status === 402) {
          throw new Error('Spoonacular API quota exceeded. Please upgrade your plan.');
        }
        throw new Error(`Spoonacular API error: ${response.status} ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Spoonacular API request failed:', error);
      throw error;
    }
  }

  // Recipe Search Methods
  async searchRecipes(query: string, options: {
    diet?: string;
    cuisine?: string;
    intolerances?: string;
    maxReadyTime?: number;
    minCalories?: number;
    maxCalories?: number;
    minProtein?: number;
    maxProtein?: number;
    minCarbs?: number;
    maxCarbs?: number;
    minFat?: number;
    maxFat?: number;
    number?: number;
    offset?: number;
    sort?: string;
    sortDirection?: 'asc' | 'desc';
    addRecipeInformation?: boolean;
  } = {}): Promise<SpoonacularSearchResult> {
    const params = {
      query,
      diet: options.diet,
      cuisine: options.cuisine,
      intolerances: options.intolerances,
      maxReadyTime: options.maxReadyTime,
      minCalories: options.minCalories,
      maxCalories: options.maxCalories,
      minProtein: options.minProtein,
      maxProtein: options.maxProtein,
      minCarbs: options.minCarbs,
      maxCarbs: options.maxCarbs,
      minFat: options.minFat,
      maxFat: options.maxFat,
      number: options.number || 10,
      offset: options.offset || 0,
      sort: options.sort,
      sortDirection: options.sortDirection,
      addRecipeInformation: options.addRecipeInformation || false,
      ...Object.fromEntries(Object.entries(options).filter(([_, v]) => v !== undefined))
    };

    return this.makeRequest<SpoonacularSearchResult>('/recipes/complexSearch', params);
  }

  async getRandomRecipes(options: {
    limitLicense?: boolean;
    tags?: string;
    number?: number;
  } = {}): Promise<{ recipes: SpoonacularRecipe[] }> {
    const params = {
      limitLicense: options.limitLicense !== false,
      tags: options.tags,
      number: options.number || 1
    };

    return this.makeRequest<{ recipes: SpoonacularRecipe[] }>('/recipes/random', params);
  }

  async findRecipesByIngredients(ingredients: string[], options: {
    ranking?: number;
    ignorePantry?: boolean;
    number?: number;
  } = {}): Promise<any[]> {
    const params = {
      ingredients: ingredients.join(','),
      ranking: options.ranking || 1,
      ignorePantry: options.ignorePantry !== false,
      number: options.number || 5
    };

    return this.makeRequest<any[]>('/recipes/findByIngredients', params);
  }

  async getRecipeInformation(id: number, includeNutrition: boolean = true): Promise<SpoonacularRecipe> {
    const params = {
      includeNutrition
    };

    return this.makeRequest<SpoonacularRecipe>(`/recipes/${id}/information`, params);
  }

  async getSimilarRecipes(id: number, number: number = 2): Promise<any[]> {
    const params = { number };
    return this.makeRequest<any[]>(`/recipes/${id}/similar`, params);
  }

  // Ingredient Methods
  async searchIngredients(query: string, options: {
    number?: number;
    metaInformation?: boolean;
    intolerances?: string;
  } = {}): Promise<SpoonacularIngredientSearchResult> {
    const params = {
      query,
      number: options.number || 10,
      metaInformation: options.metaInformation || false,
      intolerances: options.intolerances
    };

    return this.makeRequest<SpoonacularIngredientSearchResult>('/food/ingredients/search', params);
  }

  async getIngredientInformation(id: number, amount: number = 1, unit: string = 'piece'): Promise<any> {
    const params = { amount, unit };
    return this.makeRequest<any>(`/food/ingredients/${id}/information`, params);
  }

  // Meal Planning Methods
  async generateMealPlan(options: {
    timeFrame?: 'day' | 'week';
    targetCalories?: number;
    diet?: string;
    exclude?: string;
  } = {}): Promise<SpoonacularMealPlan> {
    const params = {
      timeFrame: options.timeFrame || 'day',
      targetCalories: options.targetCalories,
      diet: options.diet,
      exclude: options.exclude
    };

    return this.makeRequest<SpoonacularMealPlan>('/mealplanner/generate', params);
  }

  // Nutrition Methods
  async analyzeRecipe(recipe: {
    title: string;
    servings: number;
    ingredients: string[];
    instructions: string;
  }): Promise<any> {
    const formData = new FormData();
    formData.append('title', recipe.title);
    formData.append('servings', recipe.servings.toString());
    formData.append('ingredients', recipe.ingredients.join('\n'));
    formData.append('instructions', recipe.instructions);

    const response = await fetch(`${this.baseUrl}/recipes/analyze?apiKey=${this.apiKey}`, {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error(`Recipe analysis failed: ${response.status}`);
    }

    return response.json();
  }

  // Utility Methods
  async autocompleteRecipeSearch(query: string, number: number = 5): Promise<any[]> {
    const params = { query, number };
    return this.makeRequest<any[]>('/recipes/autocomplete', params);
  }

  async autocompleteIngredientSearch(query: string, number: number = 5): Promise<any[]> {
    const params = { query, number };
    return this.makeRequest<any[]>('/food/ingredients/autocomplete', params);
  }

  // Convert Spoonacular recipe to ChefGrocer format
  convertToChefGroverRecipe(spoonacularRecipe: SpoonacularRecipe): any {
    return {
      name: spoonacularRecipe.title,
      description: spoonacularRecipe.summary?.replace(/<[^>]*>/g, '') || 'Delicious recipe from Spoonacular',
      ingredients: spoonacularRecipe.extendedIngredients?.map(ing => ing.original) || [],
      instructions: spoonacularRecipe.analyzedInstructions?.[0]?.steps?.map(step => step.step) || 
                   spoonacularRecipe.instructions?.split('.').filter(s => s.trim()) || [],
      prepTime: spoonacularRecipe.readyInMinutes || 30,
      servings: spoonacularRecipe.servings || 4,
      difficulty: spoonacularRecipe.healthScore > 80 ? 'medium' : 'easy',
      cuisine: spoonacularRecipe.cuisines?.[0] || 'international',
      dietaryTags: [
        ...(spoonacularRecipe.vegetarian ? ['vegetarian'] : []),
        ...(spoonacularRecipe.vegan ? ['vegan'] : []),
        ...(spoonacularRecipe.glutenFree ? ['gluten-free'] : []),
        ...(spoonacularRecipe.dairyFree ? ['dairy-free'] : []),
        ...(spoonacularRecipe.ketogenic ? ['keto'] : []),
        ...(spoonacularRecipe.diets || [])
      ],
      nutritionInfo: spoonacularRecipe.nutrition ? {
        calories: spoonacularRecipe.nutrition.nutrients.find(n => n.name === 'Calories')?.amount || 0,
        protein: spoonacularRecipe.nutrition.nutrients.find(n => n.name === 'Protein')?.amount || 0,
        carbohydrates: spoonacularRecipe.nutrition.nutrients.find(n => n.name === 'Carbohydrates')?.amount || 0,
        fat: spoonacularRecipe.nutrition.nutrients.find(n => n.name === 'Fat')?.amount || 0,
        fiber: spoonacularRecipe.nutrition.nutrients.find(n => n.name === 'Fiber')?.amount || 0,
        sugar: spoonacularRecipe.nutrition.nutrients.find(n => n.name === 'Sugar')?.amount || 0,
        sodium: spoonacularRecipe.nutrition.nutrients.find(n => n.name === 'Sodium')?.amount || 0
      } : undefined,
      estimatedCost: spoonacularRecipe.pricePerServing ? spoonacularRecipe.pricePerServing / 100 : 5.99,
      tags: spoonacularRecipe.dishTypes || [],
      imageUrl: spoonacularRecipe.image,
      sourceUrl: spoonacularRecipe.sourceUrl,
      spoonacularId: spoonacularRecipe.id,
      healthScore: spoonacularRecipe.healthScore,
      aggregateLikes: spoonacularRecipe.aggregateLikes
    };
  }
}

export const spoonacularService = new SpoonacularService();