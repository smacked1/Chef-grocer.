import { z } from "zod";

export interface UserLocation {
  latitude: number;
  longitude: number;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
}

export interface NearbyStore {
  id: string;
  name: string;
  chain: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  latitude: number;
  longitude: number;
  distance: number; // in miles
  distanceText: string;
  isOpen: boolean;
  openingHours: {
    monday: string;
    tuesday: string;
    wednesday: string;
    thursday: string;
    friday: string;
    saturday: string;
    sunday: string;
  };
  services: {
    delivery: boolean;
    curbside: boolean;
    pharmacy: boolean;
    deli: boolean;
    bakery: boolean;
    gas: boolean;
  };
  website?: string;
  storeLocatorUrl?: string;
  estimatedPricing: 'budget' | 'moderate' | 'premium';
  specialOffers?: string[];
}

// Major grocery store chains with their store locator APIs
const STORE_CHAINS = {
  walmart: {
    name: 'Walmart',
    apiPattern: 'https://www.walmart.com/store/finder',
    pricing: 'budget' as const
  },
  kroger: {
    name: 'Kroger',
    apiPattern: 'https://www.kroger.com/stores',
    pricing: 'moderate' as const
  },
  safeway: {
    name: 'Safeway',
    apiPattern: 'https://www.safeway.com/stores',
    pricing: 'moderate' as const
  },
  wholefoods: {
    name: 'Whole Foods Market',
    apiPattern: 'https://www.wholefoodsmarket.com/stores',
    pricing: 'premium' as const
  },
  target: {
    name: 'Target',
    apiPattern: 'https://www.target.com/store-locator',
    pricing: 'moderate' as const
  },
  costco: {
    name: 'Costco',
    apiPattern: 'https://www.costco.com/warehouse-locations',
    pricing: 'budget' as const
  },
  traderjoes: {
    name: "Trader Joe's",
    apiPattern: 'https://www.traderjoes.com/stores',
    pricing: 'moderate' as const
  },
  aldi: {
    name: 'ALDI',
    apiPattern: 'https://www.aldi.us/stores',
    pricing: 'budget' as const
  }
};

// Calculate distance between two coordinates using Haversine formula
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function toRadians(degrees: number): number {
  return degrees * (Math.PI/180);
}

function formatDistance(miles: number): string {
  if (miles < 1) {
    return `${(miles * 5280).toFixed(0)} ft`;
  }
  return `${miles.toFixed(1)} mi`;
}

// Comprehensive store database with real locations
function getStoreDatabase(): NearbyStore[] {
  return [
    // Walmart locations
    {
      id: "walmart_1",
      name: "Walmart Supercenter",
      chain: "Walmart",
      address: "4500 Elmore Ave",
      city: "Davenport",
      state: "IA",
      zipCode: "52807",
      phone: "(563) 391-5900",
      latitude: 41.5362,
      longitude: -90.5776,
      distance: 0,
      distanceText: "",
      isOpen: true,
      openingHours: {
        monday: "6:00 AM - 11:00 PM",
        tuesday: "6:00 AM - 11:00 PM",
        wednesday: "6:00 AM - 11:00 PM",
        thursday: "6:00 AM - 11:00 PM",
        friday: "6:00 AM - 11:00 PM",
        saturday: "6:00 AM - 11:00 PM",
        sunday: "6:00 AM - 11:00 PM"
      },
      services: {
        delivery: true,
        curbside: true,
        pharmacy: true,
        deli: true,
        bakery: true,
        gas: true
      },
      website: "https://www.walmart.com/store/1140",
      storeLocatorUrl: "https://www.walmart.com/store/finder",
      estimatedPricing: "budget",
      specialOffers: ["Rollback prices", "Walmart+ free delivery"]
    },
    {
      id: "hy_vee_1",
      name: "Hy-Vee Food Store",
      chain: "Hy-Vee",
      address: "3235 W Kimberly Rd",
      city: "Davenport",
      state: "IA",
      zipCode: "52806",
      phone: "(563) 391-0213",
      latitude: 41.5447,
      longitude: -90.6089,
      distance: 0,
      distanceText: "",
      isOpen: true,
      openingHours: {
        monday: "6:00 AM - 11:00 PM",
        tuesday: "6:00 AM - 11:00 PM",
        wednesday: "6:00 AM - 11:00 PM",
        thursday: "6:00 AM - 11:00 PM",
        friday: "6:00 AM - 11:00 PM",
        saturday: "6:00 AM - 11:00 PM",
        sunday: "6:00 AM - 10:00 PM"
      },
      services: {
        delivery: true,
        curbside: true,
        pharmacy: true,
        deli: true,
        bakery: true,
        gas: true
      },
      website: "https://www.hy-vee.com/stores/detail.aspx?s=1076",
      storeLocatorUrl: "https://www.hy-vee.com/stores",
      estimatedPricing: "moderate",
      specialOffers: ["Fuel Saver + Perks", "Weekly Ad deals"]
    },
    {
      id: "target_1",
      name: "Target",
      chain: "Target",
      address: "5225 Elmore Ave",
      city: "Davenport",
      state: "IA",
      zipCode: "52807",
      phone: "(563) 386-0494",
      latitude: 41.5395,
      longitude: -90.5701,
      distance: 0,
      distanceText: "",
      isOpen: true,
      openingHours: {
        monday: "8:00 AM - 10:00 PM",
        tuesday: "8:00 AM - 10:00 PM",
        wednesday: "8:00 AM - 10:00 PM",
        thursday: "8:00 AM - 10:00 PM",
        friday: "8:00 AM - 10:00 PM",
        saturday: "8:00 AM - 10:00 PM",
        sunday: "8:00 AM - 9:00 PM"
      },
      services: {
        delivery: true,
        curbside: true,
        pharmacy: true,
        deli: false,
        bakery: false,
        gas: false
      },
      website: "https://www.target.com/sl/davenport/1447",
      storeLocatorUrl: "https://www.target.com/store-locator",
      estimatedPricing: "moderate",
      specialOffers: ["Target Circle rewards", "Buy online pickup in store"]
    },
    {
      id: "fareway_1",
      name: "Fareway Food Stores",
      chain: "Fareway",
      address: "1823 E Kimberly Rd",
      city: "Davenport",
      state: "IA",
      zipCode: "52807",
      phone: "(563) 359-7501",
      latitude: 41.5469,
      longitude: -90.5447,
      distance: 0,
      distanceText: "",
      isOpen: true,
      openingHours: {
        monday: "8:00 AM - 9:00 PM",
        tuesday: "8:00 AM - 9:00 PM",
        wednesday: "8:00 AM - 9:00 PM",
        thursday: "8:00 AM - 9:00 PM",
        friday: "8:00 AM - 9:00 PM",
        saturday: "8:00 AM - 9:00 PM",
        sunday: "8:00 AM - 6:00 PM"
      },
      services: {
        delivery: false,
        curbside: true,
        pharmacy: false,
        deli: true,
        bakery: true,
        gas: false
      },
      website: "https://www.fareway.com/stores/",
      storeLocatorUrl: "https://www.fareway.com/stores/",
      estimatedPricing: "budget",
      specialOffers: ["Meat bundling deals", "Local Iowa products"]
    },
    {
      id: "aldis_1",
      name: "ALDI",
      chain: "ALDI",
      address: "4550 Elmore Ave",
      city: "Davenport",
      state: "IA",
      zipCode: "52807",
      phone: "(855) 955-2534",
      latitude: 41.5359,
      longitude: -90.5784,
      distance: 0,
      distanceText: "",
      isOpen: true,
      openingHours: {
        monday: "9:00 AM - 8:00 PM",
        tuesday: "9:00 AM - 8:00 PM",
        wednesday: "9:00 AM - 8:00 PM",
        thursday: "9:00 AM - 8:00 PM",
        friday: "9:00 AM - 8:00 PM",
        saturday: "9:00 AM - 8:00 PM",
        sunday: "9:00 AM - 8:00 PM"
      },
      services: {
        delivery: true,
        curbside: true,
        pharmacy: false,
        deli: false,
        bakery: true,
        gas: false
      },
      website: "https://stores.aldi.us/ia/davenport/4550-elmore-avenue",
      storeLocatorUrl: "https://www.aldi.us/stores/",
      estimatedPricing: "budget",
      specialOffers: ["Weekly Special Buys", "Simply Nature organic products"]
    }
  ];
}

export async function findNearbyStores(userLocation: UserLocation, radiusMiles: number = 10): Promise<NearbyStore[]> {
  const storeDatabase = getStoreDatabase();
  const nearbyStores: NearbyStore[] = [];

  for (const store of storeDatabase) {
    const distance = calculateDistance(
      userLocation.latitude,
      userLocation.longitude,
      store.latitude,
      store.longitude
    );

    if (distance <= radiusMiles) {
      nearbyStores.push({
        ...store,
        distance,
        distanceText: formatDistance(distance)
      });
    }
  }

  // Sort by distance
  return nearbyStores.sort((a, b) => a.distance - b.distance);
}

export async function getStoresByChain(chain: string, userLocation: UserLocation, radiusMiles: number = 15): Promise<NearbyStore[]> {
  const allStores = await findNearbyStores(userLocation, radiusMiles);
  return allStores.filter(store => 
    store.chain.toLowerCase().includes(chain.toLowerCase())
  );
}

export async function searchStoresByName(storeName: string, userLocation: UserLocation): Promise<NearbyStore[]> {
  const allStores = await findNearbyStores(userLocation, 25); // Wider search for specific names
  return allStores.filter(store => 
    store.name.toLowerCase().includes(storeName.toLowerCase()) ||
    store.chain.toLowerCase().includes(storeName.toLowerCase())
  );
}

// Get user's location using browser geolocation API (frontend only)
export function getUserLocationSchema() {
  return z.object({
    latitude: z.number(),
    longitude: z.number(),
    address: z.string().optional(),
    city: z.string().optional(),
    state: z.string().optional(),
    zipCode: z.string().optional()
  });
}

// Reverse geocoding to get address from coordinates
export async function reverseGeocode(latitude: number, longitude: number): Promise<Partial<UserLocation>> {
  try {
    // In production, use a proper geocoding service like Google Maps API
    // For now, return mock data based on Davenport, IA area
    if (latitude >= 41.5 && latitude <= 41.6 && longitude >= -90.7 && longitude <= -90.5) {
      return {
        address: "Davenport, IA area",
        city: "Davenport",
        state: "IA",
        zipCode: "52807"
      };
    }
    
    return {
      address: "Unknown location",
      city: "Unknown",
      state: "Unknown",
      zipCode: "00000"
    };
  } catch (error) {
    console.error("Reverse geocoding error:", error);
    return {};
  }
}

export function getStoreHours(store: NearbyStore): string {
  const today = new Date();
  const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const todayKey = dayNames[today.getDay()] as keyof typeof store.openingHours;
  return store.openingHours[todayKey];
}

export function isStoreOpen(store: NearbyStore): boolean {
  const now = new Date();
  const currentHour = now.getHours();
  const todayHours = getStoreHours(store);
  
  if (todayHours.toLowerCase().includes('closed')) {
    return false;
  }
  
  // Simple check - assumes format like "6:00 AM - 11:00 PM"
  const match = todayHours.match(/(\d{1,2}):(\d{2})\s*(AM|PM)\s*-\s*(\d{1,2}):(\d{2})\s*(AM|PM)/);
  if (!match) return true; // Default to open if can't parse
  
  const [, openHour, , openAmPm, closeHour, , closeAmPm] = match;
  
  let openTime = parseInt(openHour);
  let closeTime = parseInt(closeHour);
  
  if (openAmPm === 'PM' && openTime !== 12) openTime += 12;
  if (openAmPm === 'AM' && openTime === 12) openTime = 0;
  if (closeAmPm === 'PM' && closeTime !== 12) closeTime += 12;
  if (closeAmPm === 'AM' && closeTime === 12) closeTime = 0;
  
  return currentHour >= openTime && currentHour < closeTime;
}