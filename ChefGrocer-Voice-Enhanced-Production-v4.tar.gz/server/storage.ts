import { type Recipe, type InsertRecipe, type MealPlan, type InsertMealPlan, type GroceryItem, type InsertGroceryItem, type PantryItem, type InsertPantryItem, type Store, type InsertStore, type ShoppingTip, type InsertShoppingTip, type FoodDatabaseItem, type InsertFoodDatabaseItem, type DeliveryService, type InsertDeliveryService, type RestaurantMenuItem, type InsertRestaurantMenuItem, type User, type InsertUser, type UpsertUser, type SubscriptionPlan, type InsertSubscriptionPlan, type PaymentTransaction, type InsertPaymentTransaction, type PremiumMealPlan, type InsertPremiumMealPlan, type Coupon, type InsertCoupon, type UserCoupon, type InsertUserCoupon } from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { users, recipes, mealPlans, groceryItems, pantryItems, stores, shoppingTips, foodDatabase, deliveryServices, restaurantMenuItems, subscriptionPlans, paymentTransactions, premiumMealPlans, coupons, userCoupons } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Recipes
  getRecipes(): Promise<Recipe[]>;
  getRecipe(id: string): Promise<Recipe | undefined>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  searchRecipes(query: string): Promise<Recipe[]>;
  
  // Meal Plans
  getMealPlans(date?: string): Promise<MealPlan[]>;
  getMealPlan(id: string): Promise<MealPlan | undefined>;
  createMealPlan(mealPlan: InsertMealPlan): Promise<MealPlan>;
  updateMealPlan(id: string, updates: Partial<MealPlan>): Promise<MealPlan>;
  deleteMealPlan(id: string): Promise<void>;
  
  // Grocery Items
  getGroceryItems(): Promise<GroceryItem[]>;
  createGroceryItem(item: InsertGroceryItem): Promise<GroceryItem>;
  updateGroceryItem(id: string, updates: Partial<GroceryItem>): Promise<GroceryItem>;
  deleteGroceryItem(id: string): Promise<void>;
  
  // Pantry Items
  getPantryItems(): Promise<PantryItem[]>;
  createPantryItem(item: InsertPantryItem): Promise<PantryItem>;
  updatePantryItem(id: string, updates: Partial<PantryItem>): Promise<PantryItem>;
  deletePantryItem(id: string): Promise<void>;
  
  // Stores
  getStores(): Promise<Store[]>;
  createStore(store: InsertStore): Promise<Store>;
  updateStore(id: string, updates: Partial<Store>): Promise<Store>;
  deleteStore(id: string): Promise<void>;
  
  // Shopping Tips
  getShoppingTips(): Promise<ShoppingTip[]>;
  createShoppingTip(tip: InsertShoppingTip): Promise<ShoppingTip>;
  getShoppingTipsByCategory(category: string): Promise<ShoppingTip[]>;
  
  // Food Database
  searchFoodDatabase(query: string, filters?: {
    category?: string;
    dietaryTags?: string[];
    maxCalories?: number;
    allergenFree?: string[];
  }): Promise<FoodDatabaseItem[]>;
  getFoodDatabaseItem(id: string): Promise<FoodDatabaseItem | undefined>;
  searchFoodDatabase(query: string): Promise<FoodDatabaseItem[]>;
  createFoodDatabaseItem(item: InsertFoodDatabaseItem): Promise<FoodDatabaseItem>;
  updateFoodDatabaseItem(id: string, updates: Partial<FoodDatabaseItem>): Promise<FoodDatabaseItem>;
  
  // Delivery Services
  getDeliveryServices(): Promise<DeliveryService[]>;
  createDeliveryService(service: InsertDeliveryService): Promise<DeliveryService>;
  getDeliveryServicesByArea(area: string): Promise<DeliveryService[]>;
  
  // Restaurant Menu Items
  getRestaurantMenuItems(filters?: {
    restaurant?: string;
    category?: string;
    maxPrice?: number;
    dietaryTags?: string[];
  }): Promise<RestaurantMenuItem[]>;
  createRestaurantMenuItem(item: InsertRestaurantMenuItem): Promise<RestaurantMenuItem>;
  getMenuItemsByDeliveryService(serviceId: string): Promise<RestaurantMenuItem[]>;
  
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  updateStripeCustomerId(userId: string, stripeCustomerId: string): Promise<User>;
  updateUserStripeCustomerId(userId: string, stripeCustomerId: string): Promise<User>;
  updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User>;
  updateUserTrialInfo(userId: string, trialEndsAt: Date, trialUsed: boolean): Promise<User>;
  
  // Subscription Plans
  getSubscriptionPlans(): Promise<SubscriptionPlan[]>;
  getSubscriptionPlan(id: string): Promise<SubscriptionPlan | undefined>;
  createSubscriptionPlan(plan: InsertSubscriptionPlan): Promise<SubscriptionPlan>;
  updateSubscriptionPlan(id: string, updates: Partial<SubscriptionPlan>): Promise<SubscriptionPlan>;
  
  // Payment Transactions
  getPaymentTransactions(userId?: string): Promise<PaymentTransaction[]>;
  getPaymentTransaction(id: string): Promise<PaymentTransaction | undefined>;
  createPaymentTransaction(transaction: InsertPaymentTransaction): Promise<PaymentTransaction>;
  updatePaymentTransaction(id: string, updates: Partial<PaymentTransaction>): Promise<PaymentTransaction>;
  
  // Premium Meal Plans
  getPremiumMealPlans(): Promise<PremiumMealPlan[]>;
  getPremiumMealPlan(id: string): Promise<PremiumMealPlan | undefined>;
  createPremiumMealPlan(plan: InsertPremiumMealPlan): Promise<PremiumMealPlan>;
  updatePremiumMealPlan(id: string, updates: Partial<PremiumMealPlan>): Promise<PremiumMealPlan>;
  
  // Subscription Plan Additional Methods
  getSubscriptionPlanByStripeId(stripePriceId: string): Promise<SubscriptionPlan | undefined>;
  
  // Coupons
  getCoupons(): Promise<Coupon[]>;
  getActiveCoupons(): Promise<Coupon[]>;
  getCoupon(id: string): Promise<Coupon | undefined>;
  getCouponByCode(code: string): Promise<Coupon | undefined>;
  createCoupon(coupon: InsertCoupon): Promise<Coupon>;
  validateCoupon(code: string, planId?: string): Promise<Coupon | null>;
  recordCouponUsage(userId: string, couponId: string, discountAmount: number): Promise<UserCoupon>;
}

export class MemStorage implements IStorage {
  private recipes: Map<string, Recipe>;
  private mealPlans: Map<string, MealPlan>;
  private groceryItems: Map<string, GroceryItem>;
  private pantryItems: Map<string, PantryItem>;
  private stores: Map<string, Store>;
  private shoppingTips: Map<string, ShoppingTip>;
  private foodDatabase: Map<string, FoodDatabaseItem>;
  private users: Map<string, User>;
  private subscriptionPlans: Map<string, SubscriptionPlan>;
  private paymentTransactions: Map<string, PaymentTransaction>;
  private premiumMealPlans: Map<string, PremiumMealPlan>;
  private deliveryServices: Map<string, DeliveryService>;
  private restaurantMenuItems: Map<string, RestaurantMenuItem>;
  private coupons: Map<string, Coupon>;
  private userCoupons: Map<string, UserCoupon>;

  constructor() {
    this.recipes = new Map();
    this.mealPlans = new Map();
    this.groceryItems = new Map();
    this.pantryItems = new Map();
    this.stores = new Map();
    this.shoppingTips = new Map();
    this.foodDatabase = new Map();
    this.deliveryServices = new Map();
    this.restaurantMenuItems = new Map();
    this.users = new Map();
    this.subscriptionPlans = new Map();
    this.paymentTransactions = new Map();
    this.premiumMealPlans = new Map();
    this.coupons = new Map();
    this.userCoupons = new Map();
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Add some initial recipes
    const sampleRecipes: InsertRecipe[] = [
      {
        name: "Blueberry Pancakes",
        description: "Fluffy pancakes with fresh blueberries",
        ingredients: ["flour", "eggs", "milk", "blueberries", "baking powder", "sugar"],
        instructions: ["Mix dry ingredients", "Combine wet ingredients", "Fold in blueberries", "Cook on griddle"],
        cookTime: 15,
        servings: 4,
        difficulty: "Easy",
        rating: 5,
        imageUrl: "https://pixabay.com/get/gc9a0b89548e8c23a0f125938c2051cbca13d96a12fc3b73cf4c0344b5dab0d222005faa18e3895176658c2937b62e518ac45508e394be9ae3ca1c5bf3f0cb1f2_1280.jpg",
        tags: ["breakfast", "sweet"]
      },
      {
        name: "Grilled Chicken Caesar",
        description: "Fresh Caesar salad with grilled chicken, croutons and parmesan",
        ingredients: ["chicken breast", "romaine lettuce", "parmesan cheese", "croutons", "caesar dressing"],
        instructions: ["Grill chicken breast", "Prepare lettuce", "Add dressing and toppings", "Serve immediately"],
        cookTime: 20,
        servings: 2,
        difficulty: "Easy",
        rating: 4,
        imageUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
        tags: ["lunch", "healthy", "salad"]
      },
      {
        name: "Herb-Crusted Salmon",
        description: "Fresh salmon with herb crust and roasted vegetables",
        ingredients: ["salmon fillet", "herbs", "vegetables", "olive oil", "lemon"],
        instructions: ["Prepare herb crust", "Season salmon", "Roast vegetables", "Bake salmon", "Serve with lemon"],
        cookTime: 25,
        servings: 2,
        difficulty: "Medium",
        rating: 5,
        imageUrl: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
        tags: ["dinner", "healthy", "fish"]
      }
    ];

    sampleRecipes.forEach(recipe => {
      const id = randomUUID();
      this.recipes.set(id, { 
        ...recipe, 
        id, 
        createdAt: new Date(), 
        description: recipe.description || null,
        rating: recipe.rating || null,
        imageUrl: recipe.imageUrl || null,
        tags: recipe.tags || null,
        calories: recipe.calories || null,
        caloriesPerServing: recipe.caloriesPerServing || null,
        nutritionInfo: recipe.nutritionInfo || null,
        estimatedCost: recipe.estimatedCost || null,
        costPerServing: recipe.costPerServing || null
      });
    });

    // Add sample meal plans for today
    const today = new Date().toISOString().split('T')[0];
    const mealPlans: InsertMealPlan[] = [
      {
        date: today,
        mealType: "breakfast",
        recipeId: Array.from(this.recipes.keys())[0],
        recipeName: "Blueberry Pancakes",
        cookTime: 15,
        status: "planned"
      },
      {
        date: today,
        mealType: "lunch",
        recipeId: Array.from(this.recipes.keys())[1],
        recipeName: "Grilled Chicken Caesar",
        cookTime: 20,
        status: "planned"
      },
      {
        date: today,
        mealType: "dinner",
        recipeId: Array.from(this.recipes.keys())[2],
        recipeName: "Herb-Crusted Salmon",
        cookTime: 25,
        status: "cooking",
        currentStep: 3
      }
    ];

    mealPlans.forEach(plan => {
      const id = randomUUID();
      this.mealPlans.set(id, { 
        ...plan, 
        id, 
        createdAt: new Date(),
        status: plan.status || null,
        recipeId: plan.recipeId || null,
        currentStep: plan.currentStep || null
      });
    });

    // Add sample grocery items with authentic pricing from local Davenport, IA stores
    const groceryItems: InsertGroceryItem[] = [
      {
        name: "Bananas",
        quantity: 3,
        category: "Produce",
        estimatedPrice: "$1.62", // $0.54/lb x 3 lbs
        completed: false,
        storeRecommendation: "ALDI",
        saleSavings: "Save $0.33 vs other stores",
        nutritionHighlights: "High in potassium and vitamin B6"
      },
      {
        name: "Chicken Breast",
        quantity: 2,
        category: "Meat & Seafood",
        estimatedPrice: "$7.78", // $3.89/lb x 2 lbs
        completed: false,
        storeRecommendation: "Fareway",
        saleSavings: "Fresh cut daily",
        nutritionHighlights: "Lean protein, 25g per serving"
      },
      {
        name: "Milk (1 gallon)",
        quantity: 1,
        category: "Dairy",
        estimatedPrice: "$2.99",
        completed: true,
        storeRecommendation: "ALDI",
        saleSavings: "Save $0.50 vs average",
        nutritionHighlights: "Calcium, vitamin D, protein"
      },
      {
        name: "Whole Wheat Bread",
        quantity: 1,
        category: "Bakery",
        estimatedPrice: "$1.89",
        completed: false,
        storeRecommendation: "ALDI",
        saleSavings: "Save $0.30 vs average",
        nutritionHighlights: "5g fiber per slice"
      },
      {
        name: "Eggs (dozen)",
        quantity: 1,
        category: "Dairy",
        estimatedPrice: "$2.29",
        completed: false,
        storeRecommendation: "ALDI",
        saleSavings: "Save $0.30 vs average",
        nutritionHighlights: "Complete protein, vitamin B12"
      },
      {
        name: "Ground Beef 80/20",
        quantity: 1,
        category: "Meat & Seafood",
        estimatedPrice: "$4.89", // per lb
        completed: false,
        storeRecommendation: "Fareway",
        saleSavings: "Fresh ground daily",
        nutritionHighlights: "Iron, zinc, protein"
      }
    ];

    groceryItems.forEach(item => {
      const id = randomUUID();
      this.groceryItems.set(id, { 
        ...item, 
        id, 
        completed: false, 
        addedBy: "user", 
        createdAt: new Date(),
        category: item.category || null,
        estimatedPrice: item.estimatedPrice || null,
        actualPrice: item.actualPrice || null,
        bestStore: item.bestStore || null,
        storeLink: item.storeLink || null,
        couponCode: item.couponCode || null,
        onSale: item.onSale || null,
        saleSavings: item.saleSavings || null
      });
    });

    // Add sample pantry items with purchase tracking
    const pantryItems: InsertPantryItem[] = [
      { 
        name: "Flour", 
        quantity: "2", 
        unit: "lbs", 
        status: "low",
        purchasePrice: "$3.99",
        purchaseDate: "2025-07-15",
        purchaseStore: "Walmart",
        calories: 455
      },
      { 
        name: "Milk", 
        quantity: "1", 
        unit: "gallon", 
        expiryDate: "2025-08-02", 
        status: "normal",
        purchasePrice: "$4.29",
        purchaseDate: "2025-07-25",
        purchaseStore: "Kroger",
        calories: 149
      },
      { 
        name: "Eggs", 
        quantity: "6", 
        unit: "count", 
        expiryDate: "2025-08-05", 
        status: "normal",
        purchasePrice: "$3.49",
        purchaseDate: "2025-07-20",
        purchaseStore: "Fresh Market",
        calories: 70
      }
    ];

    pantryItems.forEach(item => {
      const id = randomUUID();
      this.pantryItems.set(id, { 
        ...item, 
        id, 
        createdAt: new Date(),
        calories: item.calories || null,
        status: item.status || null,
        expiryDate: item.expiryDate || null,
        purchasePrice: item.purchasePrice || null,
        purchaseDate: item.purchaseDate || null,
        purchaseStore: item.purchaseStore || null
      });
    });

    // Add sample stores
    const stores: InsertStore[] = [
      {
        name: "Whole Foods Market",
        type: "grocery",
        address: "123 Organic Way, Health City, HC 12345",
        website: "https://wholefoodsmarket.com",
        priceRating: 4,
        qualityRating: 5,
        distance: "0.8 miles",
        deliveryAvailable: true,
        curbsideAvailable: true,
        specialOffers: ["10% off with Prime", "Weekly deals on organic produce"]
      },
      {
        name: "Costco Wholesale",
        type: "warehouse",
        address: "456 Bulk Avenue, Savings Town, ST 67890",
        website: "https://costco.com",
        priceRating: 2,
        qualityRating: 4,
        distance: "2.3 miles",
        deliveryAvailable: true,
        curbsideAvailable: false,
        specialOffers: ["Bulk discounts", "Gas rewards", "Executive member cashback"]
      },
      {
        name: "Kroger",
        type: "supermarket",
        address: "789 Main Street, Anywhere, AW 11111",
        website: "https://kroger.com",
        priceRating: 3,
        qualityRating: 3,
        distance: "1.2 miles",
        deliveryAvailable: true,
        curbsideAvailable: true,
        specialOffers: ["Digital coupons", "Fuel points", "Friday freebies"]
      },
      {
        name: "Local Farmers Market",
        type: "farmers_market",
        address: "City Square, Downtown, DT 22222",
        priceRating: 3,
        qualityRating: 5,
        distance: "1.5 miles",
        deliveryAvailable: false,
        curbsideAvailable: false,
        specialOffers: ["Fresh seasonal produce", "Local honey discounts"]
      }
    ];

    stores.forEach(store => {
      const id = randomUUID();
      this.stores.set(id, { 
        ...store, 
        id, 
        createdAt: new Date(),
        address: store.address || null,
        website: store.website || null,
        priceRating: store.priceRating || null,
        qualityRating: store.qualityRating || null,
        distance: store.distance || null,
        deliveryAvailable: store.deliveryAvailable || null,
        curbsideAvailable: store.curbsideAvailable || null,
        specialOffers: store.specialOffers || null
      });
    });

    // Add sample shopping tips
    const shoppingTips: InsertShoppingTip[] = [
      {
        title: "Shop the Perimeter First",
        description: "Start with fresh produce, dairy, and meats around the store's edges. These are healthier and often less processed options.",
        category: "budgeting",
        tipType: "savings",
        estimatedSavings: "15-20%",
        difficulty: "easy"
      },
      {
        title: "Use Store Apps for Digital Coupons",
        description: "Download your grocery store's app to access exclusive digital coupons and weekly deals. Many stores offer app-only discounts.",
        category: "coupons",
        tipType: "savings",
        estimatedSavings: "$10-30 per trip",
        difficulty: "easy"
      },
      {
        title: "Buy Generic/Store Brands",
        description: "Store brands are typically 20-30% cheaper than name brands and often made by the same manufacturers.",
        category: "budgeting",
        tipType: "savings",
        estimatedSavings: "20-30%",
        difficulty: "easy"
      },
      {
        title: "Shop Seasonal Produce",
        description: "Buy fruits and vegetables when they're in season for better prices and peak flavor. Freeze extras for later use.",
        category: "seasonal",
        tipType: "savings",
        estimatedSavings: "40-60%",
        difficulty: "medium"
      },
      {
        title: "Bulk Buy Non-Perishables",
        description: "Purchase items like rice, pasta, canned goods, and cleaning supplies in bulk to save money per unit.",
        category: "bulk_buying",
        tipType: "savings",
        estimatedSavings: "25-40%",
        difficulty: "medium"
      }
    ];

    shoppingTips.forEach(tip => {
      const id = randomUUID();
      this.shoppingTips.set(id, { 
        ...tip, 
        id, 
        createdAt: new Date(),
        difficulty: tip.difficulty || null,
        estimatedSavings: tip.estimatedSavings || null,
        isActive: tip.isActive || null
      });
    });

    // Add comprehensive food database
    const foodDatabaseItems: InsertFoodDatabaseItem[] = [
      {
        name: "Organic Avocado",
        category: "fruits",
        subCategory: "citrus_and_tropical",
        servingSize: "1 medium (150g)",
        calories: 234,
        nutritionInfo: {
          protein: 3,
          carbs: 12,
          fat: 21,
          fiber: 10,
          sugar: 1,
          sodium: 7,
          potassium: 690,
          vitaminA: 146,
          vitaminC: 12,
          calcium: 13,
          iron: 0.6
        },
        allergens: [],
        dietaryTags: ["vegan", "vegetarian", "keto", "paleo", "gluten_free"],
        averagePrice: "$1.50",
        seasonality: "year_round",
        storageInstructions: "Store at room temperature until ripe, then refrigerate",
        shelfLife: "7-10 days when ripe",
        preparationTips: ["Let ripen at room temperature", "Add lemon juice to prevent browning", "Perfect for guacamole"],
        commonUses: ["guacamole", "toast topping", "salads", "smoothies"],
        isOrganic: true
      },
      {
        name: "Wild-Caught Salmon Fillet",
        category: "proteins",
        subCategory: "fish_seafood",
        servingSize: "3.5 oz (100g)",
        calories: 208,
        nutritionInfo: {
          protein: 25,
          carbs: 0,
          fat: 12,
          fiber: 0,
          sugar: 0,
          sodium: 59,
          cholesterol: 59,
          potassium: 363,
          vitaminA: 12,
          vitaminC: 0,
          calcium: 9,
          iron: 0.3
        },
        allergens: ["fish"],
        dietaryTags: ["high_protein", "keto", "paleo", "omega3_rich"],
        averagePrice: "$12.99",
        seasonality: "year_round",
        storageInstructions: "Keep refrigerated at 32-38°F, use within 2 days",
        shelfLife: "2-3 days fresh, 6 months frozen",
        preparationTips: ["Don't overcook", "Season 15 minutes before cooking", "Cook skin-side down first"],
        commonUses: ["grilled", "baked", "pan-seared", "sushi"],
        isOrganic: false
      },
      {
        name: "Organic Baby Spinach",
        category: "vegetables",
        subCategory: "leafy_greens",
        servingSize: "1 cup (30g)",
        calories: 7,
        nutritionInfo: {
          protein: 0.9,
          carbs: 1.1,
          fat: 0.1,
          fiber: 0.7,
          sugar: 0.1,
          sodium: 24,
          potassium: 167,
          vitaminA: 2813,
          vitaminC: 8.4,
          calcium: 30,
          iron: 0.8
        },
        allergens: [],
        dietaryTags: ["vegan", "vegetarian", "keto", "paleo", "gluten_free", "low_carb"],
        averagePrice: "$3.99",
        seasonality: "year_round",
        storageInstructions: "Keep refrigerated in original container",
        shelfLife: "5-7 days",
        preparationTips: ["Wash just before using", "Great raw or cooked", "Wilts quickly when heated"],
        commonUses: ["salads", "smoothies", "sautéed", "pizza topping"],
        isOrganic: true
      },
      {
        name: "Greek Yogurt (Plain, Non-Fat)",
        category: "dairy",
        subCategory: "yogurt",
        brand: "Chobani",
        servingSize: "1 cup (245g)",
        calories: 130,
        nutritionInfo: {
          protein: 23,
          carbs: 9,
          fat: 0,
          fiber: 0,
          sugar: 6,
          sodium: 65,
          calcium: 200,
          potassium: 240,
          vitaminA: 0,
          vitaminC: 0,
          iron: 0.1
        },
        allergens: ["milk"],
        dietaryTags: ["vegetarian", "high_protein", "probiotics"],
        averagePrice: "$1.29",
        seasonality: "year_round",
        storageInstructions: "Keep refrigerated at 40°F or below",
        shelfLife: "2-3 weeks unopened, 1 week opened",
        preparationTips: ["Great base for smoothies", "Add honey for sweetness", "Use in baking as substitute"],
        commonUses: ["breakfast", "smoothies", "cooking substitute", "protein snack"],
        isOrganic: false
      },
      {
        name: "Quinoa (Organic, Tri-Color)",
        category: "grains",
        subCategory: "ancient_grains",
        servingSize: "1 cup cooked (185g)",
        calories: 222,
        nutritionInfo: {
          protein: 8,
          carbs: 39,
          fat: 4,
          fiber: 5,
          sugar: 2,
          sodium: 13,
          potassium: 318,
          calcium: 31,
          iron: 2.8,
          vitaminA: 5,
          vitaminC: 0
        },
        allergens: [],
        dietaryTags: ["vegan", "vegetarian", "gluten_free", "high_protein", "complete_protein"],
        averagePrice: "$4.99",
        seasonality: "year_round",
        storageInstructions: "Store in airtight container in cool, dry place",
        shelfLife: "2-3 years uncooked, 1 week cooked and refrigerated",
        preparationTips: ["Rinse before cooking", "Toast for nutty flavor", "2:1 water to quinoa ratio"],
        commonUses: ["side dish", "salads", "breakfast bowls", "stuffing"],
        isOrganic: true
      }
    ];

    foodDatabaseItems.forEach(item => {
      const id = randomUUID();
      this.foodDatabase.set(id, { 
        ...item, 
        id, 
        createdAt: new Date(), 
        updatedAt: new Date(),
        brand: item.brand || null,
        subCategory: item.subCategory || null,
        allergens: item.allergens || null,
        dietaryTags: item.dietaryTags || null,
        averagePrice: item.averagePrice || null,
        seasonality: item.seasonality || null,
        storageInstructions: item.storageInstructions || null,
        shelfLife: item.shelfLife || null,
        preparationTips: item.preparationTips || null,
        commonUses: item.commonUses || null,
        isOrganic: item.isOrganic || null
      });
    });

    // Add delivery services
    const deliveryServicesList: InsertDeliveryService[] = [
      {
        name: "DoorDash",
        type: "food_delivery",
        websiteUrl: "https://www.doordash.com",
        supportedAreas: ["nationwide_us", "canada_major_cities"],
        averageDeliveryTime: "25-45 minutes",
        deliveryFee: "$1.99-$4.99",
        minimumOrder: "$12.00",
        features: ["real_time_tracking", "scheduled_delivery", "contactless_delivery", "group_orders"],
        isActive: true
      },
      {
        name: "Grubhub",
        type: "food_delivery",
        websiteUrl: "https://www.grubhub.com",
        supportedAreas: ["nationwide_us", "london_uk"],
        averageDeliveryTime: "30-50 minutes",
        deliveryFee: "$1.99-$3.99",
        minimumOrder: "$10.00",
        features: ["real_time_tracking", "scheduled_delivery", "pickup_option", "loyalty_rewards"],
        isActive: true
      },
      {
        name: "Uber Eats",
        type: "food_delivery",
        websiteUrl: "https://www.ubereats.com",
        supportedAreas: ["global_major_cities"],
        averageDeliveryTime: "20-40 minutes",
        deliveryFee: "$0.99-$4.99",
        minimumOrder: "$12.00",
        features: ["real_time_tracking", "scheduled_delivery", "uber_one_benefits", "grocery_delivery"],
        isActive: true
      },
      {
        name: "Instacart",
        type: "grocery_delivery",
        websiteUrl: "https://www.instacart.com",
        supportedAreas: ["us_canada"],
        averageDeliveryTime: "1-3 hours",
        deliveryFee: "$3.99-$7.99",
        minimumOrder: "$35.00",
        features: ["same_day_delivery", "personal_shopper", "prescription_delivery", "bulk_items"],
        isActive: true
      }
    ];

    deliveryServicesList.forEach(service => {
      const id = randomUUID();
      this.deliveryServices.set(id, { 
        ...service, 
        id, 
        createdAt: new Date(),
        isActive: service.isActive || null,
        apiEndpoint: service.apiEndpoint || null,
        supportedAreas: service.supportedAreas || null,
        averageDeliveryTime: service.averageDeliveryTime || null,
        deliveryFee: service.deliveryFee || null,
        minimumOrder: service.minimumOrder || null,
        features: service.features || null
      });
    });

    // Add restaurant menu items with delivery links
    const restaurantItems: InsertRestaurantMenuItem[] = [
      {
        restaurantName: "Chipotle Mexican Grill",
        itemName: "Chicken Burrito Bowl",
        description: "Cilantro-lime rice, black beans, chicken, salsa, cheese, lettuce",
        category: "mains",
        price: "$8.95",
        calories: 630,
        nutritionInfo: {
          protein: 45,
          carbs: 40,
          fat: 24,
          fiber: 12,
          sugar: 4,
          sodium: 1370
        },
        allergens: ["milk"],
        dietaryTags: ["high_protein", "gluten_free"],
        ingredients: ["rice", "black beans", "chicken", "cheese", "salsa", "lettuce"],
        doordashUrl: "https://www.doordash.com/store/chipotle-mexican-grill",
        grubhubUrl: "https://www.grubhub.com/restaurant/chipotle-mexican-grill",
        ubereatsUrl: "https://www.ubereats.com/store/chipotle-mexican-grill",
        isAvailable: true
      },
      {
        restaurantName: "Sweetgreen",
        itemName: "Harvest Bowl",
        description: "Organic mesclun, roasted chicken, roasted sweet potato, apples, goat cheese, toasted almonds, balsamic vinaigrette",
        category: "mains",
        price: "$13.95",
        calories: 540,
        nutritionInfo: {
          protein: 25,
          carbs: 35,
          fat: 32,
          fiber: 8,
          sugar: 18,
          sodium: 970
        },
        allergens: ["milk", "nuts"],
        dietaryTags: ["high_protein", "organic"],
        ingredients: ["mesclun", "chicken", "sweet potato", "apples", "goat cheese", "almonds", "balsamic"],
        doordashUrl: "https://www.doordash.com/store/sweetgreen",
        grubhubUrl: "https://www.grubhub.com/restaurant/sweetgreen",
        ubereatsUrl: "https://www.ubereats.com/store/sweetgreen",
        isAvailable: true
      },
      {
        restaurantName: "Subway",
        itemName: "Turkey Breast 6-inch Sub",
        description: "Oven-roasted turkey breast on 9-grain wheat bread with vegetables",
        category: "mains",
        price: "$5.99",
        calories: 280,
        nutritionInfo: {
          protein: 18,
          carbs: 40,
          fat: 4.5,
          fiber: 5,
          sugar: 5,
          sodium: 810
        },
        allergens: ["wheat", "soy"],
        dietaryTags: ["high_protein", "low_fat"],
        ingredients: ["turkey", "wheat bread", "lettuce", "tomato", "cucumber"],
        doordashUrl: "https://www.doordash.com/store/subway",
        grubhubUrl: "https://www.grubhub.com/restaurant/subway",
        ubereatsUrl: "https://www.ubereats.com/store/subway",
        isAvailable: true
      },
      {
        restaurantName: "Panda Express",
        itemName: "Orange Chicken with Fried Rice",
        description: "Crispy chicken glazed with orange sauce served with fried rice",
        category: "mains",
        price: "$9.50",
        calories: 820,
        nutritionInfo: {
          protein: 36,
          carbs: 85,
          fat: 31,
          fiber: 3,
          sugar: 19,
          sodium: 1460
        },
        allergens: ["wheat", "soy", "eggs"],
        dietaryTags: [],
        ingredients: ["chicken", "orange sauce", "rice", "vegetables", "soy sauce"],
        doordashUrl: "https://www.doordash.com/store/panda-express",
        grubhubUrl: "https://www.grubhub.com/restaurant/panda-express",
        ubereatsUrl: "https://www.ubereats.com/store/panda-express",
        isAvailable: true
      }
    ];

    restaurantItems.forEach(item => {
      const id = randomUUID();
      const deliveryServiceId = Array.from(this.deliveryServices.keys())[0]; // Link to first delivery service
      this.restaurantMenuItems.set(id, { 
        ...item, 
        id, 
        deliveryServiceId, 
        createdAt: new Date(),
        description: item.description || null,
        ingredients: item.ingredients || null,
        imageUrl: item.imageUrl || null,
        calories: item.calories || null,
        nutritionInfo: item.nutritionInfo || null,
        allergens: item.allergens || null,
        dietaryTags: item.dietaryTags || null,
        isAvailable: item.isAvailable || null,
        doordashUrl: item.doordashUrl || null,
        grubhubUrl: item.grubhubUrl || null,
        ubereatsUrl: item.ubereatsUrl || null
      });
    });

    // Add subscription plans
    const sampleSubscriptionPlans: InsertSubscriptionPlan[] = [
      {
        name: "Free",
        description: "Basic AI cooking assistant with limited features",
        stripePriceId: "price_free", // This would be a real Stripe price ID in production
        price: 0,
        interval: "month",
        trialDays: 0,
        features: [
          "Basic recipe suggestions",
          "Simple meal planning",
          "Limited voice commands",
          "Basic grocery lists"
        ],
        isActive: true
      },
      {
        name: "Premium",
        description: "Enhanced AI cooking with advanced features and unlimited access",
        stripePriceId: "price_premium_monthly", // This would be a real Stripe price ID in production
        price: 499, // $4.99/month - proven PlateJoy pricing model
        interval: "month", 
        trialDays: 7,
        features: [
          "Unlimited AI recipe generation",
          "Advanced meal planning with nutrition tracking",
          "Full voice command suite",
          "Smart grocery lists with price comparison",
          "Premium recipe collections",
          "Nutritional analysis and tracking",
          "Priority customer support",
          "Export meal plans and shopping lists"
        ],
        isActive: true
      },
      {
        name: "Pro",
        description: "Professional chef-level features for restaurants and power users",
        stripePriceId: "price_pro_monthly", // This would be a real Stripe price ID in production
        price: 999, // $9.99 in cents - competitive with PlateJoy
        interval: "month",
        trialDays: 14,
        features: [
          "Everything in Premium",
          "Restaurant partnership features",
          "Advanced dietary restriction management",
          "Professional recipe scaling and conversion",
          "Inventory management with expiration tracking",
          "Meal prep optimization",
          "Integration with smart kitchen appliances",
          "Custom nutrition goals and tracking",
          "Advanced voice AI with natural conversation",
          "Recipe creation from photo analysis",
          "Bulk meal planning for families",
          "White-label customization options"
        ],
        isActive: true
      },
      {
        name: "Premium Yearly",
        description: "Enhanced AI cooking with advanced features - yearly billing",
        stripePriceId: "price_premium_yearly", // This would be a real Stripe price ID in production
        price: 4799, // $47.99 yearly (20% savings vs $59.88 monthly)
        interval: "year",
        trialDays: 7,
        features: [
          "Everything in Premium Plan",
          "Save 20% compared to monthly billing",
          "Priority customer support",
          "Early access to new features",
          "Annual recipe collection bonus"
        ],
        isActive: true
      },
      {
        name: "Lifetime Pass",
        description: "One-time payment for lifetime access to all ChefGrocer features - Limited time launch offer!",
        stripePriceId: "price_lifetime_pass", // This would be a real Stripe price ID in production
        price: 9999, // $99.99 - premium lifetime value pricing
        maxUsers: 1000, // Limited launch offer for urgency
        currentUsers: 47, // Show growing adoption
        interval: "lifetime",
        trialDays: 0,
        features: [
          "Everything in Pro Plan - Forever",
          "Lifetime access to all current and future features",
          "No recurring payments ever",
          "Priority customer support for life",
          "Early access to all new features",
          "Exclusive lifetime member perks",
          "Restaurant partnership features",
          "Advanced dietary restriction management",
          "Professional recipe scaling and conversion",
          "Inventory management with expiration tracking",
          "Meal prep optimization",
          "Integration with smart kitchen appliances",
          "Custom nutrition goals and tracking",
          "Advanced voice AI with natural conversation",
          "Recipe creation from photo analysis",
          "Bulk meal planning for families",
          "Complete offline recipe access",
          "Export to professional recipe formats",
          "Founding member status and badge"
        ],
        isActive: true
      }
    ];

    sampleSubscriptionPlans.forEach(plan => {
      const id = randomUUID();
      this.subscriptionPlans.set(id, { 
        ...plan, 
        id, 
        createdAt: new Date(),
        isActive: plan.isActive || null,
        trialDays: plan.trialDays || null,
        maxUsers: plan.maxUsers || null,
        currentUsers: plan.currentUsers || 0
      });
    });

    // Add sample coupons for promotional campaigns
    const sampleCoupons: InsertCoupon[] = [
      {
        code: "LAUNCH50",
        name: "Launch Special - 50% Off",
        description: "Limited time: 50% off your first month of ChefGrocer Premium",
        discountType: "percentage",
        discountValue: 50,
        minAmount: 0,
        maxUses: 1000,
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
        isActive: true,
        applicablePlans: ["price_premium_monthly", "price_premium_yearly"]
      },
      {
        code: "EARLYBIRD",
        name: "Early Bird Discount",
        description: "Get $10 off the Lifetime Pass (first 100 users only)",
        discountType: "fixed_amount",
        discountValue: 1000, // $10.00 in cents
        minAmount: 5000, // Minimum for lifetime pass
        maxUses: 100,
        validUntil: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
        isActive: true,
        applicablePlans: ["price_lifetime_pass"]
      },
      {
        code: "FIRSTUSER",
        name: "First User Bonus",
        description: "Extended 21-day trial for early adopters",
        discountType: "percentage",
        discountValue: 100, // 100% off trial period
        minAmount: 0,
        maxUses: 200, // Limited to first 200 users
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
        isActive: true,
        applicablePlans: ["price_premium_monthly", "price_premium_yearly"]
      },
      {
        code: "ANNUAL25",
        name: "Annual Plan Bonus",
        description: "Extra 25% off yearly subscriptions",
        discountType: "percentage",
        discountValue: 25,
        minAmount: 2000, // Only for yearly plan
        maxUses: 500,
        validUntil: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000), // 60 days from now
        isActive: true,
        applicablePlans: ["price_premium_yearly"]
      },
      {
        code: "APPSTORE25",
        name: "App Store Launch - 25% Off",
        description: "App Store exclusive: 25% off for new iOS users",
        discountType: "percentage",
        discountValue: 25,
        minAmount: 0,
        maxUses: 2000,
        validUntil: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000), // 90 days for App Store launch
        isActive: true,
        applicablePlans: ["price_premium_monthly", "price_premium_yearly"]
      }
    ];

    sampleCoupons.forEach(coupon => {
      const id = randomUUID();
      this.coupons.set(id, { 
        ...coupon, 
        id, 
        usedCount: 0, 
        createdAt: new Date(),
        description: coupon.description || null,
        isActive: coupon.isActive || null,
        minAmount: coupon.minAmount || null,
        maxUses: coupon.maxUses || null,
        validUntil: coupon.validUntil || null,
        applicablePlans: coupon.applicablePlans || null
      });
    });

    // Add sample premium meal plans
    const samplePremiumMealPlans: InsertPremiumMealPlan[] = [
      {
        name: "7-Day Mediterranean Diet",
        description: "A complete Mediterranean diet meal plan focusing on fresh ingredients, healthy fats, and balanced nutrition",
        price: 1999, // $19.99 in cents
        duration: 7,
        meals: [
          {
            day: 1,
            breakfast: "Greek Yogurt with Berries and Honey",
            lunch: "Mediterranean Quinoa Salad",
            dinner: "Grilled Salmon with Roasted Vegetables",
            snacks: ["Mixed Nuts", "Hummus with Vegetables"]
          },
          {
            day: 2,
            breakfast: "Avocado Toast with Tomatoes",
            lunch: "Greek Salad with Grilled Chicken",
            dinner: "Herb-Crusted Cod with Lemon Rice",
            snacks: ["Greek Yogurt", "Olives and Cheese"]
          },
          {
            day: 3,
            breakfast: "Mediterranean Scrambled Eggs",
            lunch: "Lentil and Vegetable Soup",
            dinner: "Grilled Chicken with Roasted Eggplant",
            snacks: ["Fresh Fruit", "Almonds"]
          }
        ],
        nutritionGoals: {
          calories: 1800,
          protein: 120,
          carbs: 200,
          fat: 70
        },
        dietaryTags: ["mediterranean", "heart_healthy", "high_protein"],
        imageUrl: "https://images.unsplash.com/photo-1490645935967-10de6ba17061",
        isActive: true
      },
      {
        name: "14-Day Keto Kickstart",
        description: "A comprehensive ketogenic diet plan designed to help you enter ketosis while enjoying delicious low-carb meals",
        price: 2999, // $29.99 in cents
        duration: 14,
        meals: [
          {
            day: 1,
            breakfast: "Keto Bacon and Eggs",
            lunch: "Avocado Chicken Salad",
            dinner: "Grilled Steak with Broccoli",
            snacks: ["Cheese and Pepperoni", "Macadamia Nuts"]
          },
          {
            day: 2,
            breakfast: "Keto Smoothie with MCT Oil",
            lunch: "Cauliflower Rice Bowl",
            dinner: "Baked Salmon with Asparagus",
            snacks: ["Pork Rinds", "Avocado with Salt"]
          }
        ],
        nutritionGoals: {
          calories: 1600,
          protein: 100,
          carbs: 25,
          fat: 130
        },
        dietaryTags: ["keto", "low_carb", "high_fat"],
        imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd",
        isActive: true
      }
    ];

    samplePremiumMealPlans.forEach(plan => {
      const id = randomUUID();
      this.premiumMealPlans.set(id, { 
        ...plan, 
        id, 
        createdAt: new Date(),
        imageUrl: plan.imageUrl || null,
        isActive: plan.isActive || null,
        dietaryTags: plan.dietaryTags || null,
        nutritionGoals: plan.nutritionGoals || null
      });
    });
  }

  // Recipe methods
  async getRecipes(): Promise<Recipe[]> {
    return Array.from(this.recipes.values());
  }

  async getRecipe(id: string): Promise<Recipe | undefined> {
    return this.recipes.get(id);
  }

  async createRecipe(insertRecipe: InsertRecipe): Promise<Recipe> {
    const id = randomUUID();
    const recipe: Recipe = { ...insertRecipe, id, createdAt: new Date() };
    this.recipes.set(id, recipe);
    return recipe;
  }

  async searchRecipes(query: string): Promise<Recipe[]> {
    const recipes = Array.from(this.recipes.values());
    return recipes.filter(recipe => 
      recipe.name.toLowerCase().includes(query.toLowerCase()) ||
      recipe.description?.toLowerCase().includes(query.toLowerCase()) ||
      recipe.ingredients.some(ingredient => ingredient.toLowerCase().includes(query.toLowerCase()))
    );
  }

  // Meal Plan methods
  async getMealPlans(date?: string): Promise<MealPlan[]> {
    const mealPlans = Array.from(this.mealPlans.values());
    if (date) {
      return mealPlans.filter(plan => plan.date === date);
    }
    return mealPlans;
  }

  async getMealPlan(id: string): Promise<MealPlan | undefined> {
    return this.mealPlans.get(id);
  }

  async createMealPlan(insertMealPlan: InsertMealPlan): Promise<MealPlan> {
    const id = randomUUID();
    const mealPlan: MealPlan = { ...insertMealPlan, id, createdAt: new Date() };
    this.mealPlans.set(id, mealPlan);
    return mealPlan;
  }

  async updateMealPlan(id: string, updates: Partial<MealPlan>): Promise<MealPlan> {
    const mealPlan = this.mealPlans.get(id);
    if (!mealPlan) throw new Error("Meal plan not found");
    
    const updated = { ...mealPlan, ...updates };
    this.mealPlans.set(id, updated);
    return updated;
  }

  async deleteMealPlan(id: string): Promise<void> {
    this.mealPlans.delete(id);
  }

  // Grocery Item methods
  async getGroceryItems(): Promise<GroceryItem[]> {
    return Array.from(this.groceryItems.values());
  }

  async createGroceryItem(insertItem: InsertGroceryItem): Promise<GroceryItem> {
    const id = randomUUID();
    const item: GroceryItem = { ...insertItem, id, completed: false, addedBy: "user", createdAt: new Date() };
    this.groceryItems.set(id, item);
    return item;
  }

  async updateGroceryItem(id: string, updates: Partial<GroceryItem>): Promise<GroceryItem> {
    const item = this.groceryItems.get(id);
    if (!item) throw new Error("Grocery item not found");
    
    const updated = { ...item, ...updates };
    this.groceryItems.set(id, updated);
    return updated;
  }

  async deleteGroceryItem(id: string): Promise<void> {
    this.groceryItems.delete(id);
  }

  // Pantry Item methods
  async getPantryItems(): Promise<PantryItem[]> {
    return Array.from(this.pantryItems.values());
  }

  async createPantryItem(insertItem: InsertPantryItem): Promise<PantryItem> {
    const id = randomUUID();
    const item: PantryItem = { ...insertItem, id, createdAt: new Date() };
    this.pantryItems.set(id, item);
    return item;
  }

  async updatePantryItem(id: string, updates: Partial<PantryItem>): Promise<PantryItem> {
    const item = this.pantryItems.get(id);
    if (!item) throw new Error("Pantry item not found");
    
    const updated = { ...item, ...updates };
    this.pantryItems.set(id, updated);
    return updated;
  }

  async deletePantryItem(id: string): Promise<void> {
    this.pantryItems.delete(id);
  }

  // Store methods
  async getStores(): Promise<Store[]> {
    return Array.from(this.stores.values());
  }

  async createStore(insertStore: InsertStore): Promise<Store> {
    const id = randomUUID();
    const store: Store = { ...insertStore, id, createdAt: new Date() };
    this.stores.set(id, store);
    return store;
  }

  async updateStore(id: string, updates: Partial<Store>): Promise<Store> {
    const store = this.stores.get(id);
    if (!store) throw new Error("Store not found");
    
    const updated = { ...store, ...updates };
    this.stores.set(id, updated);
    return updated;
  }

  async deleteStore(id: string): Promise<void> {
    this.stores.delete(id);
  }

  // Shopping Tips methods
  async getShoppingTips(): Promise<ShoppingTip[]> {
    return Array.from(this.shoppingTips.values());
  }

  async createShoppingTip(insertTip: InsertShoppingTip): Promise<ShoppingTip> {
    const id = randomUUID();
    const tip: ShoppingTip = { ...insertTip, id, createdAt: new Date() };
    this.shoppingTips.set(id, tip);
    return tip;
  }

  async getShoppingTipsByCategory(category: string): Promise<ShoppingTip[]> {
    const tips = Array.from(this.shoppingTips.values());
    return tips.filter(tip => tip.category === category && tip.isActive);
  }

  // Food Database methods
  async searchFoodDatabase(query: string, filters?: {
    category?: string;
    dietaryTags?: string[];
    maxCalories?: number;
    allergenFree?: string[];
  }): Promise<FoodDatabaseItem[]> {
    const foods = Array.from(this.foodDatabase.values());
    return foods.filter(food => {
      const matchesQuery = food.name.toLowerCase().includes(query.toLowerCase()) ||
                          food.category.toLowerCase().includes(query.toLowerCase()) ||
                          (food.subCategory && food.subCategory.toLowerCase().includes(query.toLowerCase()));
      
      if (!matchesQuery) return false;
      
      if (filters?.category && food.category !== filters.category) return false;
      if (filters?.maxCalories && food.calories > filters.maxCalories) return false;
      if (filters?.dietaryTags?.length && !filters.dietaryTags.some(tag => food.dietaryTags.includes(tag))) return false;
      if (filters?.allergenFree?.length && filters.allergenFree.some(allergen => food.allergens.includes(allergen))) return false;
      
      return true;
    });
  }

  async getFoodDatabaseItem(id: string): Promise<FoodDatabaseItem | undefined> {
    return this.foodDatabase.get(id);
  }

  async searchFoodDatabase(query: string): Promise<FoodDatabaseItem[]> {
    const searchTerms = query.toLowerCase().split(' ');
    return Array.from(this.foodDatabase.values()).filter(item => {
      const searchableText = `${item.name} ${item.category} ${item.subCategory || ''} ${item.brand || ''}`.toLowerCase();
      return searchTerms.some(term => searchableText.includes(term));
    });
  }

  async createFoodDatabaseItem(insertItem: InsertFoodDatabaseItem): Promise<FoodDatabaseItem> {
    const id = randomUUID();
    const item: FoodDatabaseItem = { ...insertItem, id, createdAt: new Date(), updatedAt: new Date() };
    this.foodDatabase.set(id, item);
    return item;
  }

  async updateFoodDatabaseItem(id: string, updates: Partial<FoodDatabaseItem>): Promise<FoodDatabaseItem> {
    const item = this.foodDatabase.get(id);
    if (!item) throw new Error("Food item not found");
    
    const updated = { ...item, ...updates, updatedAt: new Date() };
    this.foodDatabase.set(id, updated);
    return updated;
  }

  // Delivery Services methods
  async getDeliveryServices(): Promise<DeliveryService[]> {
    return Array.from(this.deliveryServices.values()).filter(service => service.isActive);
  }

  async createDeliveryService(insertService: InsertDeliveryService): Promise<DeliveryService> {
    const id = randomUUID();
    const service: DeliveryService = { ...insertService, id, createdAt: new Date() };
    this.deliveryServices.set(id, service);
    return service;
  }

  async getDeliveryServicesByArea(area: string): Promise<DeliveryService[]> {
    const services = Array.from(this.deliveryServices.values());
    return services.filter(service => 
      service.isActive && 
      service.supportedAreas.some(supportedArea => 
        supportedArea.toLowerCase().includes(area.toLowerCase()) ||
        area.toLowerCase().includes(supportedArea.toLowerCase())
      )
    );
  }

  // Restaurant Menu Items methods
  async getRestaurantMenuItems(filters?: {
    restaurant?: string;
    category?: string;
    maxPrice?: number;
    dietaryTags?: string[];
  }): Promise<RestaurantMenuItem[]> {
    const items = Array.from(this.restaurantMenuItems.values());
    return items.filter(item => {
      if (!item.isAvailable) return false;
      if (filters?.restaurant && !item.restaurantName.toLowerCase().includes(filters.restaurant.toLowerCase())) return false;
      if (filters?.category && item.category !== filters.category) return false;
      if (filters?.maxPrice && parseFloat(item.price.replace('$', '')) > filters.maxPrice) return false;
      if (filters?.dietaryTags?.length && !filters.dietaryTags.some(tag => item.dietaryTags.includes(tag))) return false;
      
      return true;
    });
  }

  async createRestaurantMenuItem(insertItem: InsertRestaurantMenuItem): Promise<RestaurantMenuItem> {
    const id = randomUUID();
    const item: RestaurantMenuItem = { ...insertItem, id, createdAt: new Date() };
    this.restaurantMenuItems.set(id, item);
    return item;
  }

  async getMenuItemsByDeliveryService(serviceId: string): Promise<RestaurantMenuItem[]> {
    const items = Array.from(this.restaurantMenuItems.values());
    return items.filter(item => item.deliveryServiceId === serviceId && item.isAvailable);
  }

  // Users methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id, createdAt: new Date(), updatedAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) throw new Error("User not found");
    
    const updated = { ...user, ...updates, updatedAt: new Date() };
    this.users.set(id, updated);
    return updated;
  }

  async updateStripeCustomerId(userId: string, stripeCustomerId: string): Promise<User> {
    return this.updateUser(userId, { stripeCustomerId });
  }

  async updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User> {
    return this.updateUser(userId, { stripeCustomerId, stripeSubscriptionId });
  }

  // Subscription Plans methods
  async getSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    return Array.from(this.subscriptionPlans.values()).filter(plan => plan.isActive);
  }

  async getSubscriptionPlan(id: string): Promise<SubscriptionPlan | undefined> {
    return this.subscriptionPlans.get(id);
  }

  async createSubscriptionPlan(insertPlan: InsertSubscriptionPlan): Promise<SubscriptionPlan> {
    const id = randomUUID();
    const plan: SubscriptionPlan = { ...insertPlan, id, createdAt: new Date() };
    this.subscriptionPlans.set(id, plan);
    return plan;
  }

  async updateSubscriptionPlan(id: string, updates: Partial<SubscriptionPlan>): Promise<SubscriptionPlan> {
    const plan = this.subscriptionPlans.get(id);
    if (!plan) throw new Error("Subscription plan not found");
    
    const updated = { ...plan, ...updates };
    this.subscriptionPlans.set(id, updated);
    return updated;
  }

  // Payment Transactions methods
  async getPaymentTransactions(userId?: string): Promise<PaymentTransaction[]> {
    const transactions = Array.from(this.paymentTransactions.values());
    return userId ? transactions.filter(t => t.userId === userId) : transactions;
  }

  async getPaymentTransaction(id: string): Promise<PaymentTransaction | undefined> {
    return this.paymentTransactions.get(id);
  }

  async createPaymentTransaction(insertTransaction: InsertPaymentTransaction): Promise<PaymentTransaction> {
    const id = randomUUID();
    const transaction: PaymentTransaction = { ...insertTransaction, id, createdAt: new Date(), updatedAt: new Date() };
    this.paymentTransactions.set(id, transaction);
    return transaction;
  }

  async updatePaymentTransaction(id: string, updates: Partial<PaymentTransaction>): Promise<PaymentTransaction> {
    const transaction = this.paymentTransactions.get(id);
    if (!transaction) throw new Error("Payment transaction not found");
    
    const updated = { ...transaction, ...updates, updatedAt: new Date() };
    this.paymentTransactions.set(id, updated);
    return updated;
  }

  // Premium Meal Plans methods
  async getPremiumMealPlans(): Promise<PremiumMealPlan[]> {
    return Array.from(this.premiumMealPlans.values()).filter(plan => plan.isActive);
  }

  async getPremiumMealPlan(id: string): Promise<PremiumMealPlan | undefined> {
    return this.premiumMealPlans.get(id);
  }

  async createPremiumMealPlan(insertPlan: InsertPremiumMealPlan): Promise<PremiumMealPlan> {
    const id = randomUUID();
    const plan: PremiumMealPlan = { ...insertPlan, id, createdAt: new Date() };
    this.premiumMealPlans.set(id, plan);
    return plan;
  }

  async updatePremiumMealPlan(id: string, updates: Partial<PremiumMealPlan>): Promise<PremiumMealPlan> {
    const plan = this.premiumMealPlans.get(id);
    if (!plan) throw new Error("Premium meal plan not found");
    
    const updated = { ...plan, ...updates };
    this.premiumMealPlans.set(id, updated);
    return updated;
  }

  // Additional Subscription Plan methods
  async getSubscriptionPlanByStripeId(stripePriceId: string): Promise<SubscriptionPlan | undefined> {
    return Array.from(this.subscriptionPlans.values()).find(plan => plan.stripePriceId === stripePriceId);
  }

  // Coupon methods
  async getCoupons(): Promise<Coupon[]> {
    return Array.from(this.coupons.values());
  }

  async getActiveCoupons(): Promise<Coupon[]> {
    const now = new Date();
    return Array.from(this.coupons.values()).filter(coupon => 
      coupon.isActive && 
      (!coupon.validUntil || new Date(coupon.validUntil) > now) &&
      (!coupon.maxUses || coupon.usedCount < coupon.maxUses)
    );
  }

  async getCoupon(id: string): Promise<Coupon | undefined> {
    return this.coupons.get(id);
  }

  async getCouponByCode(code: string): Promise<Coupon | undefined> {
    return Array.from(this.coupons.values()).find(coupon => coupon.code === code);
  }

  async createCoupon(insertCoupon: InsertCoupon): Promise<Coupon> {
    const id = randomUUID();
    const coupon: Coupon = { ...insertCoupon, id, usedCount: 0, createdAt: new Date() };
    this.coupons.set(id, coupon);
    return coupon;
  }

  async validateCoupon(code: string, planId?: string): Promise<Coupon | null> {
    const coupon = await this.getCouponByCode(code);
    if (!coupon) return null;

    const now = new Date();
    
    // Check if coupon is active
    if (!coupon.isActive) return null;
    
    // Check if coupon has expired
    if (coupon.validUntil && new Date(coupon.validUntil) < now) return null;
    
    // Check if coupon has exceeded max uses
    if (coupon.maxUses && coupon.usedCount >= coupon.maxUses) return null;
    
    // Check if coupon is valid from the start date
    if (coupon.validFrom && new Date(coupon.validFrom) > now) return null;
    
    // Check if coupon applies to the specific plan
    if (planId && coupon.applicablePlans.length > 0 && !coupon.applicablePlans.includes(planId)) {
      return null;
    }

    return coupon;
  }

  async recordCouponUsage(userId: string, couponId: string, discountAmount: number): Promise<UserCoupon> {
    const id = randomUUID();
    const userCoupon: UserCoupon = {
      id,
      userId,
      couponId,
      usedAt: new Date(),
      discountAmount,
      createdAt: new Date()
    };
    
    this.userCoupons.set(id, userCoupon);
    
    // Update coupon usage count
    const coupon = this.coupons.get(couponId);
    if (coupon) {
      coupon.usedCount = (coupon.usedCount || 0) + 1;
      this.coupons.set(couponId, coupon);
    }
    
    return userCoupon;
  }

  // Additional User methods for trial support
  async updateUserTrialInfo(userId: string, trialEndsAt: Date, trialUsed: boolean): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updated = { ...user, trialEndsAt, trialUsed, updatedAt: new Date() };
    this.users.set(userId, updated);
    return updated;
  }

  async updateUserStripeCustomerId(userId: string, stripeCustomerId: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updated = { ...user, stripeCustomerId, updatedAt: new Date() };
    this.users.set(userId, updated);
    return updated;
  }
}

export const storage = new MemStorage();
