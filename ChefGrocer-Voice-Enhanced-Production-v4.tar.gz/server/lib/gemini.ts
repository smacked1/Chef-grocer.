import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function analyzeIngredient(ingredientQuery: string) {
  try {
    const prompt = `
You are a nutrition expert and ingredient database. Analyze the ingredient: "${ingredientQuery}"

Provide detailed information in JSON format with this exact structure:
[
  {
    "name": "exact ingredient name",
    "category": "main category (e.g., vegetables, fruits, proteins, grains, dairy)",
    "subCategory": "subcategory if applicable",
    "brand": "brand name if specific brand mentioned",
    "servingSize": "standard serving size (e.g., '1 cup', '100g')",
    "calories": number,
    "nutritionInfo": {
      "protein": number_in_grams,
      "carbs": number_in_grams,
      "fat": number_in_grams,
      "fiber": number_in_grams,
      "sugar": number_in_grams,
      "sodium": number_in_mg
    },
    "allergens": ["list", "of", "common", "allergens"],
    "commonUses": ["cooking uses", "preparation methods", "recipe types"],
    "storageInstructions": "how to store properly",
    "estimatedPrice": "$X.XX approximate price"
  }
]

If multiple ingredients are mentioned or if there are common variations, include up to 3 most relevant results.
Use accurate nutrition data and be precise with measurements.
For allergens, include common ones like "dairy", "nuts", "gluten", "soy", etc.
`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "array",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              category: { type: "string" },
              subCategory: { type: "string" },
              brand: { type: "string" },
              servingSize: { type: "string" },
              calories: { type: "number" },
              nutritionInfo: {
                type: "object",
                properties: {
                  protein: { type: "number" },
                  carbs: { type: "number" },
                  fat: { type: "number" },
                  fiber: { type: "number" },
                  sugar: { type: "number" },
                  sodium: { type: "number" }
                },
                required: ["protein", "carbs", "fat", "fiber", "sugar", "sodium"]
              },
              allergens: {
                type: "array",
                items: { type: "string" }
              },
              commonUses: {
                type: "array",
                items: { type: "string" }
              },
              storageInstructions: { type: "string" },
              estimatedPrice: { type: "string" }
            },
            required: ["name", "category", "servingSize", "calories", "nutritionInfo", "allergens", "commonUses"]
          }
        }
      },
      contents: prompt,
    });

    const rawJson = response.text;
    if (rawJson) {
      const results = JSON.parse(rawJson);
      return Array.isArray(results) ? results : [results];
    }
    
    return null;
  } catch (error) {
    console.error("Gemini ingredient analysis error:", error);
    return null;
  }
}

export async function generateRecipeFromIngredients(ingredients: string[]) {
  try {
    const prompt = `
Create a recipe using these ingredients: ${ingredients.join(', ')}

Provide a complete recipe in JSON format:
{
  "name": "recipe name",
  "description": "brief description",
  "ingredients": ["ingredient with measurements"],
  "instructions": ["step by step instructions"],
  "cookTime": minutes_as_number,
  "servings": number_of_servings,
  "difficulty": "easy/medium/hard",
  "nutritionInfo": {
    "calories": per_serving,
    "protein": grams,
    "carbs": grams,
    "fat": grams
  },
  "tags": ["cuisine type", "meal type", "dietary info"]
}
`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        responseMimeType: "application/json"
      },
      contents: prompt,
    });

    const rawJson = response.text;
    if (rawJson) {
      return JSON.parse(rawJson);
    }
    
    return null;
  } catch (error) {
    console.error("Gemini recipe generation error:", error);
    return null;
  }
}