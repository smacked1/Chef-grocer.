import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Mic, Clock, Users } from "lucide-react";
import { MealPlan } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useVoice } from "@/hooks/use-voice";
import { useToast } from "@/hooks/use-toast";

interface MealPlanCardProps {
  mealPlan: MealPlan;
}

export function MealPlanCard({ mealPlan }: MealPlanCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { speak } = useVoice();

  const updateMealPlanMutation = useMutation({
    mutationFn: async (updates: Partial<MealPlan>) => {
      const response = await apiRequest("PATCH", `/api/meal-plans/${mealPlan.id}`, updates);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/meal-plans'] });
    }
  });

  const handleStartCooking = () => {
    updateMealPlanMutation.mutate({ 
      status: "cooking", 
      currentStep: 1 
    });
    
    speak(`Starting to cook ${mealPlan.recipeName}. Let me guide you through the recipe.`);
    
    toast({
      title: "Started Cooking",
      description: `Now cooking ${mealPlan.recipeName}`,
    });
  };

  const handleVoiceAssist = () => {
    const message = mealPlan.status === "cooking" 
      ? `You're currently on step ${mealPlan.currentStep} of ${mealPlan.recipeName}. Would you like me to read the next step?`
      : `Ready to start cooking ${mealPlan.recipeName}? This recipe takes about ${mealPlan.cookTime} minutes.`;
    
    speak(message);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "cooking":
        return "bg-orange-500";
      case "completed":
        return "bg-green-500";
      default:
        return "bg-blue-500";
    }
  };

  const getMealTypeTime = (mealType: string) => {
    switch (mealType) {
      case "breakfast":
        return "8:00 AM";
      case "lunch":
        return "12:30 PM";
      case "dinner":
        return "7:00 PM";
      default:
        return "";
    }
  };

  const getMealImage = (mealType: string, recipeName: string) => {
    // Return appropriate image based on meal type and recipe name
    const recipeLower = recipeName.toLowerCase();
    
    // Breakfast items
    if (recipeLower.includes("pancake")) {
      return "https://images.unsplash.com/photo-1528207776546-365bb710ee93?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("waffle")) {
      return "https://images.unsplash.com/photo-1562376552-0d160a2f238d?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("eggs") || recipeLower.includes("omelet") || recipeLower.includes("scrambled")) {
      return "https://images.unsplash.com/photo-1482049016688-2d3e1b311543?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("toast") || recipeLower.includes("bagel")) {
      return "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("cereal") || recipeLower.includes("granola")) {
      return "https://images.unsplash.com/photo-1574168280581-9b7e4f5b8e66?w=120&h=120&fit=crop&auto=format";
    }
    
    // Lunch/Dinner items
    if (recipeLower.includes("caesar") || recipeLower.includes("salad")) {
      return "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("salmon")) {
      return "https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("chicken")) {
      return "https://images.unsplash.com/photo-1532550907401-a500c9a57435?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("pasta") || recipeLower.includes("spaghetti")) {
      return "https://images.unsplash.com/photo-1621996346565-e3dbc353d2e5?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("pizza")) {
      return "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("burger") || recipeLower.includes("sandwich")) {
      return "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("steak") || recipeLower.includes("beef")) {
      return "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("fish") || recipeLower.includes("seafood")) {
      return "https://images.unsplash.com/photo-1559847844-5315695dadae?w=120&h=120&fit=crop&auto=format";
    }
    if (recipeLower.includes("soup")) {
      return "https://images.unsplash.com/photo-1547592180-85f173990554?w=120&h=120&fit=crop&auto=format";
    }
    
    // Default based on meal type
    switch (mealType.toLowerCase()) {
      case "breakfast":
        return "https://images.unsplash.com/photo-1528207776546-365bb710ee93?w=120&h=120&fit=crop&auto=format";
      case "lunch":
        return "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=120&h=120&fit=crop&auto=format";
      case "dinner":
        return "https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=120&h=120&fit=crop&auto=format";
      default:
        return "https://images.unsplash.com/photo-1482049016688-2d3e1b311543?w=120&h=120&fit=crop&auto=format";
    }
  };

  return (
    <Card className={`hover:shadow-md transition-shadow ${
      mealPlan.status === "cooking" ? "border-orange-500 bg-orange-50" : ""
    }`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img 
              src={getMealImage(mealPlan.mealType, mealPlan.recipeName)}
              alt={mealPlan.recipeName}
              className="w-16 h-16 rounded-lg object-cover"
            />
            <div>
              <h4 className="font-semibold text-gray-900">{mealPlan.recipeName}</h4>
              <p className="text-gray-600 text-sm capitalize">
                {mealPlan.mealType} • {getMealTypeTime(mealPlan.mealType)}
              </p>
              <div className="flex items-center space-x-2 mt-1">
                <Clock className="w-4 h-4 text-green-600" />
                <span className="text-green-600 text-sm font-medium">
                  {mealPlan.cookTime} min cook time
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {mealPlan.status === "cooking" ? (
              <Badge className={`${getStatusColor(mealPlan.status)} text-white`}>
                Step {mealPlan.currentStep} of 6
              </Badge>
            ) : (
              <Button
                onClick={handleStartCooking}
                disabled={updateMealPlanMutation.isPending}
                className="p-2 text-blue-600 hover:bg-blue-50"
                variant="ghost"
              >
                <Play className="w-4 h-4" />
              </Button>
            )}
            
            <Button
              onClick={handleVoiceAssist}
              className="p-2 text-gray-400 hover:bg-gray-50"
              variant="ghost"
            >
              <Mic className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
